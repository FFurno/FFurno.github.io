%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 10
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a


%%%%%%%%%%%%%%%%%%%%%%%%%
% Preparation
clear, clc;
addpath('./Tools/FRED_Interface_v1.1/');


%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing Excel File
COMPUSTAT_1962 = readtable('./Inputs/Compustat_1962.csv');
COMPUSTAT_1962 = COMPUSTAT_1962(:, 2:end);

COMPUSTAT_2017 = readtable('./Inputs/Compustat_2017.csv');
COMPUSTAT_2017 = COMPUSTAT_2017(:, 2:end);

% Scaling with Base Year = 1963
COMPUSTAT_1962_scaled = COMPUSTAT_1962;

for index_i = 1 : size(COMPUSTAT_1962, 1)
    for index_j = 2 : length(COMPUSTAT_1962.Properties.VariableNames)
        var_name_aux = COMPUSTAT_1962.Properties.VariableNames{index_j};
        var_aux = COMPUSTAT_1962.(var_name_aux);
        COMPUSTAT_1962_scaled.(var_name_aux)(index_i) = 100 * var_aux(index_i) ./ var_aux(4);
    end
    
    
end

% Scaling with Base Year = 2017
COMPUSTAT_2017_scaled = COMPUSTAT_2017;

for index_i = 1 : size(COMPUSTAT_2017, 1)
    for index_j = 2 : length(COMPUSTAT_2017.Properties.VariableNames)
        var_name_aux = COMPUSTAT_2017.Properties.VariableNames{index_j};
        var_aux = COMPUSTAT_2017.(var_name_aux);
        COMPUSTAT_2017_scaled.(var_name_aux)(index_i) = 100 * var_aux(index_i) ./ var_aux(2);
    end
    
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aggregate Data - Fred Download

labels = {'I', 'D'};
%series_id = {'PNFIA', 'A2218C1A027NBEA'};
series_id = {'PNFIA', 'B1447C1A027NBEA'};
request = containers.Map(labels, series_id);
Kennedy_Aggregate_Data = FRED_Interface(request);
Trump_Aggregate_Data = FRED_Interface(request);


% Subsample 
Kennedy_Aggregate_Data = Kennedy_Aggregate_Data(timerange("1960-01-01","1967-01-01"), :);
Kennedy_Aggregate_Data = retime(Kennedy_Aggregate_Data, 'yearly', 'mean');
Trump_Aggregate_Data = Trump_Aggregate_Data(timerange("2016-01-01","2020-01-01"), :);
Trump_Aggregate_Data = retime(Trump_Aggregate_Data, 'yearly', 'mean');

% Re-Scaling
Kennedy_Aggregate_Data.I = 100 *  Kennedy_Aggregate_Data.I ./ Kennedy_Aggregate_Data.I(4);
Kennedy_Aggregate_Data.D = 100 *  Kennedy_Aggregate_Data.D ./ Kennedy_Aggregate_Data.D(4);
Trump_Aggregate_Data.I = 100 *  Trump_Aggregate_Data.I ./ Trump_Aggregate_Data.I(2);
Trump_Aggregate_Data.D = 100 *  Trump_Aggregate_Data.D ./ Trump_Aggregate_Data.D(2);





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 10
figure('Name', 'Figure 10');
set(gcf, 'Color', 'w', 'Position', [275.40 292.20 1052.80 734.40]);

subplot(2, 2, 3)
hold on
plot(COMPUSTAT_1962_scaled.Year, COMPUSTAT_1962_scaled.CPX, '-o', 'LineWidth', 1.5);
plot(COMPUSTAT_1962_scaled.Year, COMPUSTAT_1962_scaled.DIV, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([1960, 1966]);
xticks(1960:1966);
ylim([80, 180]);
ax_aux = get(gca); line([1963, 1963], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
ax_aux = get(gca); line([1964, 1964], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
xlabel('Year');
title('Kennedy 1960s - C-Corporations');



subplot(2, 2, 4)
hold on
plot(COMPUSTAT_2017_scaled.Year, COMPUSTAT_2017_scaled.CPX, '-o', 'LineWidth', 1.5);
plot(COMPUSTAT_2017_scaled.Year, COMPUSTAT_2017_scaled.PAYOUT, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([2016, 2019]);
xticks(2016:2019);
ylim([80, 180]);
ax_aux = get(gca); line([2017, 2017], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
xlabel('Year');
title('Trump 2017 - C-Corporations');



subplot(2, 2, 1)
hold on
plot(1960:1966, Kennedy_Aggregate_Data.I, '-o', 'LineWidth', 1.5);
plot(1960:1966, Kennedy_Aggregate_Data.D, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([1960, 1966]);
xticks(1960:1966);
ax_aux = get(gca); line([1963, 1963], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
ax_aux = get(gca); line([1964, 1964], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
xlabel('Year');
title('Kennedy 1960s - Macro Aggregates');
legend('Investment', 'Payouts', 'Location', 'northwest');



subplot(2, 2, 2)
hold on
plot(2016:2019, Trump_Aggregate_Data.I, '-o', 'LineWidth', 1.5);
plot(2016:2019, Trump_Aggregate_Data.D, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([2016, 2019]);
xticks(2016:2019);
ylim([80, 150]);
ax_aux = get(gca); line([2017, 2017], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
title('Trump 2017 - Macro Aggregates');
