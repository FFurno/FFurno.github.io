%% The Macroeconomic Effects of Corporate Tax Reforms
% Run All Figures
% Expected Completion Time: Less than 2 Minutes
% Notes: Some Bonus Figures Included

clear; close all; clc;

tic
run Figure_1.m
run Figure_2.m
run Figure_3_4.m
run Figure_5.m
run Figure_6.m
run Figure_7.m
run Figure_8.m
run Figure_9.m
run Figure_10.m
run Figure_11.m
run Figure_12.m
run Figure_13.m
toc





