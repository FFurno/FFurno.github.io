%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 6
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: R2020a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Ops
clear, clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing Excel File
SOI.Receipts = readtable('./Inputs/Corporations_vs_PassThrough.xlsx', 'sheet', 'Business_Receipts');
SOI.VA = readtable('./Inputs/Corporations_vs_PassThrough.xlsx', 'sheet', 'VA');
SOI.Payout = readtable('./Inputs/Corporations_vs_PassThrough.xlsx', 'sheet', 'Payouts');
SOI.CAPEX = readtable('./Inputs/Corporations_vs_PassThrough.xlsx', 'sheet', 'CAPEX');
SOI.Returns = readtable('./Inputs/Corporations_vs_PassThrough.xlsx', 'sheet', 'Returns');

% Aggregating Pass-Through Businesses
SOI.Receipts.PT = SOI.Receipts.S_Corps + SOI.Receipts.Partnerships + SOI.Receipts.Sole_Prop;
SOI.VA.PT = SOI.VA.S_Corps + SOI.VA.Partnerships + SOI.VA.Sole_Prop;
SOI.CAPEX.PT = SOI.CAPEX.S_Corps + SOI.CAPEX.Partnerships;
SOI.Returns.PT = SOI.Returns.S_Corps + SOI.Returns.Partnerships + SOI.Returns.Sole_Prop;

% Aggregating All Businesses
SOI.Receipts.Total = SOI.Receipts.C_Corps + SOI.Receipts.PT;
SOI.VA.Total = SOI.VA.C_Corps + SOI.VA.PT;
SOI.CAPEX.Total = SOI.CAPEX.C_Corps + SOI.CAPEX.PT;
SOI.Returns.Total = SOI.Returns.C_Corps + SOI.Returns.PT;
SOI.Payout.Total = SOI.Payout.Corps_Dividends + SOI.Payout.PT_Income;



% C-Corporations Shares
C_Share.Year = SOI.Receipts.Year;
C_Share.Receipts = 100 * SOI.Receipts.C_Corps ./ SOI.Receipts.Total;
C_Share.VA = 100 * SOI.VA.C_Corps ./ SOI.VA.Total;
C_Share.CAPEX = 100 * SOI.CAPEX.C_Corps ./ SOI.CAPEX.Total;
C_Share.Payout = 100 * SOI.Payout.Corps_Dividends ./ SOI.Payout.Total;
C_Share.Returns = 100 * SOI.Returns.C_Corps ./ SOI.Returns.Total;


%%%%%%%%%%%%%%%%%%%%%%%%%
% Re-Scaling Data

% Selecting Base Year
Base_Year = 2017;

% Field List
Field_list = fieldnames(SOI);

% Scaling with Base Year = 2017
SOI_scaled = SOI;


for var_index = 1: length(Field_list)
    Field_aux = Field_list{var_index};
    for index_i = 1 : size(SOI.(Field_aux), 1)
        Base_Year_index = find(SOI.(Field_aux).Year == Base_Year);
        for index_j = 2 : length(SOI.(Field_aux).Properties.VariableNames)
            var_name_aux = SOI.(Field_aux).Properties.VariableNames{index_j};
            var_aux = SOI.(Field_aux).(var_name_aux);
            SOI_scaled.(Field_aux).(var_name_aux)(index_i) = 100 * var_aux(index_i) ./ var_aux(Base_Year_index);
        end
    end
end
clear Field_aux Field_list index_i index_j var_aux var_index var_name_aux



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
First_year = 2015;
Last_year = 2018;


% Figure 6
figure('Name', 'Figure 6');
set(gcf, 'Color', 'w', 'Position', [242.6000 350.6000 1.2512e+03 591.2000]);

subplot(2, 3, 1)
hold on
plot(SOI_scaled.VA.Year, SOI_scaled.Receipts.C_Corps, '-o', 'LineWidth', 1.5);
plot(SOI_scaled.VA.Year, SOI_scaled.Receipts.PT, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ylim([90, 110]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
title('Output');
legend('C-Corporations', 'Pass-Through', 'Location', 'northwest', 'FontSize', 7);
xticks(First_year:1:Last_year)

subplot(2, 3, 2)
hold on
plot(SOI_scaled.CAPEX.Year, SOI_scaled.CAPEX.C_Corps, '-o', 'LineWidth', 1.5);
plot(SOI_scaled.CAPEX.Year, SOI_scaled.CAPEX.PT, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ylim([70, 130]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
title('Investment');
xticks(First_year:1:Last_year)


subplot(2, 3, 3)
hold on
plot(SOI_scaled.Payout.Year, SOI_scaled.Payout.Corps_Dividends, '-o', 'LineWidth', 1.5);
plot(SOI_scaled.Payout.Year, SOI_scaled.Payout.PT_Income, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ylim([90, 115]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
title('Income Reported by Individuals');
xticks(First_year:1:Last_year)



subplot(2, 3, 4)
hold on
plot(C_Share.Year, C_Share.Receipts, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
ylabel('C-Corps Share');
ytickformat('percentage');
title('Output');
xticks(First_year:1:Last_year)



subplot(2, 3, 5)
hold on
plot(C_Share.Year, C_Share.CAPEX, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
ylabel('C-Corps Share');
ytickformat('percentage');
title('Investment');
xticks(First_year:1:Last_year)




subplot(2, 3, 6)
hold on
plot(C_Share.Year, C_Share.Payout, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--')
xlabel('Year');
ylabel('C-Corps Share');
ytickformat('percentage');
title('Income Reported by Individuals');
xticks(First_year:1:Last_year)






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bonus Figure - Re-Incorporation as C-Corps
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w');
hold on
plot(C_Share.Year, C_Share.Returns, '-o', 'LineWidth', 1.5);
hold off
grid, box on;
xlim([First_year, Last_year]);
ax_aux = get(gca); line([2017.5, 2017.5], ax_aux.YLim, 'Color', 'k', 'LineStyle', '--');
xlabel('Year');
ylabel('C-Corps Share');
ytickformat('percentage');
title('Filed Tax Returns');
xticks(First_year:1:Last_year)


