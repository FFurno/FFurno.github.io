%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 7
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;
addpath(genpath('./Tools/'));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model - TCJA-17 Simulation


% Baseline
dynare Dynare_Model_Baseline
steady;
[Trump_level, Trump] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level, Trump] = Transition_additional_vars_aux(Trump_level, Trump);


% Robustness to IES
dynare Dynare_Model_Baseline
set_param_value('sigma', (0.5)^(-1) );
steady;
[Trump_level_low_IES, Trump_low_IES] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_low_IES, Trump_low_IES] = Transition_additional_vars_aux(Trump_level_low_IES, Trump_low_IES);


dynare Dynare_Model_Baseline
set_param_value('sigma', (2.0)^(-1) );
steady;
[Trump_level_high_IES, Trump_high_IES] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_high_IES, Trump_high_IES] = Transition_additional_vars_aux(Trump_level_high_IES, Trump_high_IES);



% Robustness to alpha
dynare Dynare_Model_Baseline
set_param_value('alpha_Corp', 0.32);
set_param_value('alpha_PT', 0.32);
steady;
[Trump_level_low_alpha, Trump_low_alpha] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_low_alpha, Trump_low_alpha] = Transition_additional_vars_aux(Trump_level_low_alpha, Trump_low_alpha);


dynare Dynare_Model_Baseline
set_param_value('alpha_Corp', 0.38 );
set_param_value('alpha_PT', 0.38 );
steady;
[Trump_level_high_alpha, Trump_high_alpha] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_high_alpha, Trump_high_alpha] = Transition_additional_vars_aux(Trump_level_high_alpha, Trump_high_alpha);



% Robustness to introduction of tax credit rate
dynare Dynare_Model_Baseline
steady;
[Trump_level_credits, Trump_credits] = Transition_extractor([(0.35-0.10), 0], [(0.21-0.08), 1], 10000);
[Trump_level_credits, Trump_credits] = Transition_additional_vars_aux(Trump_level_credits, Trump_credits);



%%%%%%%%%%%%%
% Cleaning
clean_dynare_output('Dynare_Model_Baseline');


%%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing TCJA-17 Empirical Evidence
load('./Inputs/Empirics_Response.mat');

% Using Corporate Tax Revenues Adjusted for Repatriated Profit
TCJA_17_MACRO.T_pi.Actual = TCJA_17_MACRO.T_pi.Actual_Adjusted;

IRF_MACRO = IRF_rescaling_aux(TCJA_17_MACRO, 2017);
IRF_IBES  = IRF_rescaling_aux(TCJA_17_IBES, 2017);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualizing
Color1 = [0, 0.4470, 0.7410];
Color2 = [0.8500, 0.3250, 0.0980];
Color3 = [0.4660, 0.6740, 0.1880];
x_axis = [2017:2017+length(Trump.C_Aggregate)-1];
Bands_alpha = 0.3;
periods_plot = 5;




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 7
figure('Name', 'Figure 7');
set(gcf, 'Color', 'w', 'Position',  [266.6000 261 1.0048e+03 685.6000]);
subplot(2, 2, 2);
hold on
plot(x_axis,[Trump.Y_Aggregate_Real],  '-o','LineWidth', 1.5);
plot(x_axis,[Trump.I_Aggregate_Real], '-o', 'LineWidth', 1.5);
plot(x_axis,[Trump.T_Corp], '-o', 'LineWidth', 1.5);
hold off
box on, grid;
ylim([-80, +10]);
ytickformat('percentage');
title('Model - Macro Aggregates');
xlim([2017, 2017+periods_plot-1]);


subplot(2, 2, 1);
hold on
plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'LineWidth', 1.5);
plot(IRF_MACRO.Year, [IRF_MACRO.I.point], '-o', 'LineWidth', 1.5);
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'LineWidth', 1.5);
hold off
box on, grid;
ylim([-80, +10]);
ytickformat('percentage');
title('Data - Macro Aggregates');
xlim([2017, 2017+periods_plot-1]);
legend('Output', 'Investment', 'Corporate Tax Revenues', 'Location', 'southeast')


subplot(2, 2, 4);
hold on
plot(x_axis,[Trump.Y_Corp],  '-o','LineWidth', 1.5);
plot(x_axis,[Trump.I_Corp], '-o', 'LineWidth', 1.5);
plot(x_axis,[Trump.D_Corp], '-o', 'Color', Color3, 'LineWidth', 1.5);
hold off
box on, grid;
ytickformat('percentage');
title('Model - C-Corporations');
ylim([0, 30]);
xlim([2017, 2017+periods_plot-1]);


subplot(2, 2, 3);
hold on
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'LineWidth', 1.5);
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'LineWidth', 1.5);
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color3, 'LineWidth', 1.5);
hold off
box on, grid;
ytickformat('percentage');
title('Data - C-Corporations');
xlim([2017, 2017+periods_plot-1]);
ylim([0, 30]);
legend('Output', 'Investment', 'Payout', 'Location', 'southeast')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Quantitative Comparison - Baseline & Robustness 
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [34.6000 442.6000 1.3944e+03 508.8000]);
subplot(2, 4, 1)
hold on
plot_model = plot(x_axis, Trump.Y_Aggregate_Real, '-o', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.Y.lb, IRF_MACRO.Y.ub, Color2, Bands_alpha);  
plot_data = plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 4]);
box on, grid;
ytickformat('percentage');
title('Aggregate Output');
legend([plot_data, plot_model], 'Data', 'Model', 'Location', 'northeast');


subplot(2, 4, 2)
hold on
plot(x_axis, Trump.I_Aggregate_Real, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.I_NR.lb, IRF_MACRO.I_NR.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.I_NR.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 6]);
box on, grid;
ytickformat('percentage');
title('Aggregate Non-Residential Investment')



subplot(2, 4, 3)
hold on 
plot(x_axis, Trump.L_Aggregate, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.E.lb, IRF_MACRO.E.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, IRF_MACRO.E.point, '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 1]);
title('Aggregate Employment');
box on, grid;
ytickformat('percentage');



subplot(2, 4, 4)
hold on
plot(x_axis, Trump.T_Corp, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.T_pi.lb, IRF_MACRO.T_pi.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('Corporate Tax Revenues')



subplot(2, 4, 5)
hold on
plot(x_axis, Trump.Y_Corp, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.Y.lb, IRF_IBES.Y.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 20]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Output')


subplot(2, 4, 6)
hold on
plot(x_axis, Trump.I_Corp, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.I.lb, IRF_IBES.I.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Investment')

subplot(2, 4, 7)
hold on
plot(x_axis, Trump.L_Corp, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.E.lb, IRF_IBES.E.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.E.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 10]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Employment')



subplot(2, 4, 8)
hold on
plot(x_axis, Trump.D_Corp, '-o', 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.PAY.lb, IRF_IBES.PAY.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Payouts')





%%%%%%%%%%%%%
% Robustness to IES
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [34.6000 442.6000 1.3944e+03 508.8000]);

subplot(2, 4, 1)
hold on
plot_model = plot(x_axis, Trump.Y_Aggregate_Real, '-o', 'Color', Color1, 'LineWidth', 1.5);
plot_model_alt1 = plot(x_axis, Trump_low_IES.Y_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot_model_alt2 = plot(x_axis, Trump_high_IES.Y_Aggregate_Real, '-d', 'Color', Color1, 'LineWidth', 1.5);

confidence_bands(IRF_MACRO.Year, IRF_MACRO.Y.lb, IRF_MACRO.Y.ub, Color2, Bands_alpha);  
plot_data = plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 4]);
box on, grid;
ytickformat('percentage');
title('Aggregate Output');
legend([plot_data, plot_model, plot_model_alt1, plot_model_alt2], 'Data', 'Model - IES = 1', 'Model - IES = 0.5', 'Model - IES = 2', 'Location', 'northeast');


subplot(2, 4, 2)
hold on
plot(x_axis, Trump.I_Aggregate_Real, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.I_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.I_Aggregate_Real, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.I_NR.lb, IRF_MACRO.I_NR.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.I_NR.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 6]);
box on, grid;
ytickformat('percentage');
title('Aggregate Non-Residential Investment')



subplot(2, 4, 3)
hold on 
plot(x_axis, Trump.L_Aggregate, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.L_Aggregate, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.L_Aggregate, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.E.lb, IRF_MACRO.E.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, IRF_MACRO.E.point, '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 1]);
title('Aggregate Employment');
box on, grid;
ytickformat('percentage');



subplot(2, 4, 4)
hold on
plot(x_axis, Trump.T_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.T_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.T_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.T_pi.lb, IRF_MACRO.T_pi.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('Corporate Tax Revenues')



subplot(2, 4, 5)
hold on
plot(x_axis, Trump.Y_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.Y_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.Y_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.Y.lb, IRF_IBES.Y.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 20]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Output')


subplot(2, 4, 6)
hold on
plot(x_axis, Trump.I_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.I_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.I_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.I.lb, IRF_IBES.I.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Investment')

subplot(2, 4, 7)
hold on
plot(x_axis, Trump.L_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.L_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.L_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.E.lb, IRF_IBES.E.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.E.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 10]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Employment')



subplot(2, 4, 8)
hold on
plot(x_axis, Trump.D_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_IES.D_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_IES.D_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.PAY.lb, IRF_IBES.PAY.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Payouts')




%%%%%%%%%%%%%
% Robustness to alpha
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [34.6000 442.6000 1.3944e+03 508.8000]);

subplot(2, 4, 1)
hold on
plot_model = plot(x_axis, Trump.Y_Aggregate_Real, '-o', 'Color', Color1, 'LineWidth', 1.5);
plot_model_alt1 = plot(x_axis, Trump_low_alpha.Y_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot_model_alt2 = plot(x_axis, Trump_high_alpha.Y_Aggregate_Real, '-d', 'Color', Color1, 'LineWidth', 1.5);

confidence_bands(IRF_MACRO.Year, IRF_MACRO.Y.lb, IRF_MACRO.Y.ub, Color2, Bands_alpha);  
plot_data = plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 4]);
box on, grid;
ytickformat('percentage');
title('Aggregate Output');
legend([plot_data, plot_model, plot_model_alt1, plot_model_alt2], 'Data', 'Model - \alpha = 0.35', 'Model - \alpha = 0.32', 'Model - \alpha = 0.38', 'Location', 'northeast');


subplot(2, 4, 2)
hold on
plot(x_axis, Trump.I_Aggregate_Real, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.I_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.I_Aggregate_Real, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.I_NR.lb, IRF_MACRO.I_NR.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.I_NR.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 6]);
box on, grid;
ytickformat('percentage');
title('Aggregate Non-Residential Investment')



subplot(2, 4, 3)
hold on 
plot(x_axis, Trump.L_Aggregate, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.L_Aggregate, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.L_Aggregate, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.E.lb, IRF_MACRO.E.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, IRF_MACRO.E.point, '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 1]);
title('Aggregate Employment');
box on, grid;
ytickformat('percentage');



subplot(2, 4, 4)
hold on
plot(x_axis, Trump.T_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.T_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.T_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.T_pi.lb, IRF_MACRO.T_pi.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('Corporate Tax Revenues')



subplot(2, 4, 5)
hold on
plot(x_axis, Trump.Y_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.Y_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.Y_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.Y.lb, IRF_IBES.Y.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 20]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Output')


subplot(2, 4, 6)
hold on
plot(x_axis, Trump.I_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.I_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.I_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.I.lb, IRF_IBES.I.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Investment')

subplot(2, 4, 7)
hold on
plot(x_axis, Trump.L_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.L_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.L_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.E.lb, IRF_IBES.E.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.E.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 10]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Employment')



subplot(2, 4, 8)
hold on
plot(x_axis, Trump.D_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_low_alpha.D_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_high_alpha.D_Corp, '-d', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.PAY.lb, IRF_IBES.PAY.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Payouts')





%%%%%%%%%%%%%
% Robustness to tax credit rate
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [34.6000 442.6000 1.3944e+03 508.8000]);

subplot(2, 4, 1)
hold on
plot_model = plot(x_axis, Trump.Y_Aggregate_Real, '-o', 'Color', Color1, 'LineWidth', 1.5);
plot_model_alt1 = plot(x_axis, Trump_credits.Y_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);

confidence_bands(IRF_MACRO.Year, IRF_MACRO.Y.lb, IRF_MACRO.Y.ub, Color2, Bands_alpha);  
plot_data = plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 4]);
box on, grid;
ytickformat('percentage');
title('Aggregate Output');
legend([plot_data, plot_model, plot_model_alt1], 'Data', 'Model - Baseline', 'Model - w/ Tax Credits', 'Location', 'northeast');


subplot(2, 4, 2)
hold on
plot(x_axis, Trump.I_Aggregate_Real, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.I_Aggregate_Real, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.I_NR.lb, IRF_MACRO.I_NR.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.I_NR.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 6]);
box on, grid;
ytickformat('percentage');
title('Aggregate Non-Residential Investment')



subplot(2, 4, 3)
hold on 
plot(x_axis, Trump.L_Aggregate, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.L_Aggregate, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.E.lb, IRF_MACRO.E.ub, Color2, Bands_alpha);  
plot_aggregate = plot(IRF_MACRO.Year, IRF_MACRO.E.point, '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 1]);
title('Aggregate Employment');
box on, grid;
ytickformat('percentage');



subplot(2, 4, 4)
hold on
plot(x_axis, Trump.T_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.T_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.T_pi.lb, IRF_MACRO.T_pi.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('Corporate Tax Revenues')



subplot(2, 4, 5)
hold on
plot(x_axis, Trump.Y_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.Y_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.Y.lb, IRF_IBES.Y.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 20]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Output')


subplot(2, 4, 6)
hold on
plot(x_axis, Trump.I_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.I_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.I.lb, IRF_IBES.I.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Investment')

subplot(2, 4, 7)
hold on
plot(x_axis, Trump.L_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.L_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.E.lb, IRF_IBES.E.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.E.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 10]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Employment')



subplot(2, 4, 8)
hold on
plot(x_axis, Trump.D_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_credits.D_Corp, '-*', 'Color', Color1, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.PAY.lb, IRF_IBES.PAY.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Payouts')




