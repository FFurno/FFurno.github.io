%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 11
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;
addpath(genpath('./Tools/'));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model - Trump vs Kennedy

%%%%%%%%%%%%%
% Trump's TJCA-17
dynare Dynare_Model_Extended
steady;
[Trump_level_extended, Trump_extended] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_extended, Trump_extended] = Transition_additional_vars_aux(Trump_level_extended, Trump_extended);


%%%%%%%%%%%%%
% Kennedy's Tax Cuts 
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.70);
set_param_value('delta_pi_before', 0.10);
set_param_value('delta_pi_after', 0.1857);
steady;
[Kennedy_level_extended, Kennedy_extended] = Transition_extractor([0.52, 0], [0.48, 1], 10000);
[Kennedy_level_extended, Kennedy_extended] = Transition_additional_vars_aux(Kennedy_level_extended, Kennedy_extended);


%%%%%%
% Cleaning Temp Files
clean_dynare_output('Dynare_Model_Extended');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Additional Calculations 

% Computation Horizon
horizon_years = 20;
horizon_index = 1 + horizon_years;

% Variable Preparation
X = categorical({'GDP', 'Investment', 'Payouts'});
X = reordercats(X,{'GDP', 'Investment', 'Payouts'});


% Percentage Deviations from Steady-State
Deviation_1961 = [Kennedy_extended.Y_Aggregate_Real(horizon_index),  ...
            Kennedy_extended.I_Aggregate_Real(horizon_index),  ...
            Kennedy_extended.D_Corp(horizon_index)];
       
Deviation_2017 = [Trump_extended.Y_Aggregate_Real(horizon_index),  ...
            Trump_extended.I_Aggregate_Real(horizon_index),  ...
            Trump_extended.D_Corp(horizon_index)];

Cumulative_Deviation_1961 = [(sum(Kennedy_level_extended.Y_Aggregate_Real(1:horizon_index)) ./ (Kennedy_level_extended.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Kennedy_level_extended.I_Aggregate_Real(1:horizon_index)) ./ (Kennedy_level_extended.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Kennedy_level_extended.D_Corp(1:horizon_index)) ./ (Kennedy_level_extended.D_Corp(1) * horizon_index) - 1) * 100];

Cumulative_Deviation_2017 = [(sum(Trump_level_extended.Y_Aggregate_Real(1:horizon_index)) ./ (Trump_level_extended.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Trump_level_extended.I_Aggregate_Real(1:horizon_index)) ./ (Trump_level_extended.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Trump_level_extended.D_Corp(1:horizon_index)) ./ (Trump_level_extended.D_Corp(1) * horizon_index) - 1) * 100];

       
        
        
% Computing Corporate Tax Multipliers
[~, Cumulative_Multiplier_1961] = Multiplier_aux(Kennedy_level_extended);
[~, Cumulative_Multiplier_2017] = Multiplier_aux(Trump_level_extended);


Multiplier_1961 = [-Cumulative_Multiplier_1961.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_1961.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_1961.D_Corp(horizon_index)];

Multiplier_2017 = [-Cumulative_Multiplier_2017.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017.D_Corp(horizon_index)];


%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualization Parameters
Color1 = [0, 0.4470, 0.7410];
Color2 = [0.8500, 0.3250, 0.0980];
Color3 = [0.9290, 0.6940, 0.1250];
Color4 = [0.4660, 0.6740, 0.1880];
Color5 = [0.4940, 0.1840, 0.5560];
plotting_horizon = 20 + 2;

% Group = Macro Variable
% Stacks per Group = Number of Reforms Considered
% Stack Elements = Number of Counterfactuals per Reform
NumGroupsPerAxis = 3;
NumStacksPerGroup = 2;
NumStackElements = 1;

% labels to use on tick marks for groups
groupLabels = { 'GDP'; 'Investment'; 'Payouts'};
stackData_Deviation = zeros(NumGroupsPerAxis,NumStacksPerGroup,NumStackElements);
stackData_Multiplier = zeros(NumGroupsPerAxis,NumStacksPerGroup,NumStackElements);

stackData_Deviation(:, :, 1) = [Cumulative_Deviation_2017', Cumulative_Deviation_1961'];
stackData_Multiplier(:, :, 1) = [Multiplier_2017', Multiplier_1961'];


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 11
figure('Name', 'Figure 11');
set(gcf, 'Color', 'w', 'Position', [353.8000 545 1.1048e+03 357.6000]);


%%%%%%%%%%%%%%%%%%
% 1) Cumulative Deviation from SS
subplot(1, 2, 1)
H = plotBarStackGroups(stackData_Deviation, groupLabels);
set(H(1, 1), 'FaceColor', Color1);
set(H(2, 1), 'FaceColor', Color2);
box on;
legend([H(1,1), H(2,1)], 'Trump Reform', 'Kennedy Reforms', 'Location', 'northwest');
title('Long-Run Change');
ylabel('20-Year Cumulative Change');
ytickformat('percentage');

% Labels for Trump Reform
htext = text(H(1,1).XData, H(1,1).YData, {num2str(round(H(1,1).YData(1), 2)); num2str(round(H(1,1).YData(2), 2)); num2str(round(H(1,1).YData(3), 2))});    
set(htext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')

% Labels for Kennedy Reform
hhtext = text(H(2,1).XData(1:2), H(2,1).YData(1:2), {num2str(round(H(2,1).YData(1), 2)); num2str(round(H(2,1).YData(2), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')
hhhtext = text(H(2,1).XData(3), H(2,1).YData(3), num2str(round(H(2,1).YData(3), 2))); 
set(hhhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')


%%%%%%%%%%%%%%%%%%
% 2) Corporate Tax Multiplier
subplot(1, 2, 2)
H = plotBarStackGroups(stackData_Multiplier, groupLabels);
set(H(1, 1), 'FaceColor', Color1);
set(H(2, 1), 'FaceColor', Color2);
box on;
title('Corporate Tax Multiplier');
ylabel('20-Year Cumulative Multiplier');
ylim([0,3]);

% Labels for Trump Reform
htext = text(H(1,1).XData, H(1,1).YData, {num2str(round(H(1,1).YData(1), 2)); num2str(round(H(1,1).YData(2), 2)); num2str(round(H(1,1).YData(3), 2))});    
set(htext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')

% Labels for Kennedy Reform
hhtext = text(H(2,1).XData(1:2), H(2,1).YData(1:2), {num2str(round(H(2,1).YData(1), 2)); num2str(round(H(2,1).YData(2), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')
hhhtext = text(H(2,1).XData(3), H(2,1).YData(3), num2str(round(H(2,1).YData(3), 2))); 
set(hhhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')






