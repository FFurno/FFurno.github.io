%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 5
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: R2020a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Ops
clear, clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing Excel File
SOI_Receipts = readtable('./Inputs/Business_Activity_1960-2018.xls', 'sheet', 'Business_Receipts');



%%%%%%%%%%%%%%%%%%%%%%%%%
% Creating Shares
SOI_Receipts.PT_Receipts = SOI_Receipts.Nonfarm_SoleProp + SOI_Receipts.Partnership + SOI_Receipts.S_Corps;
SOI_Receipts.Total_Receipts = SOI_Receipts.PT_Receipts + SOI_Receipts.C_Corps;
SOI_Receipts.C_Corps_Share = [SOI_Receipts.C_Corps ./ SOI_Receipts.Total_Receipts] * 100;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure for Presentation
Color.blue = 	[0, 0.4470, 0.7410];
Color.red = [0.6350, 0.0780, 0.1840];
labels = {'S-Corporations (22%)','Partnerships (15%)','Sole-Proprietorships (4%)', 'C-Corporations (59%)'};
mymap =  [Color.red; 0.8 * Color.red; 0.5 * Color.red; Color.blue];


% Index for Pre-Reform Year
Target_year = 2017;
Target_year_position = find(SOI_Receipts.Year == Target_year);
Official_data_start = find(SOI_Receipts.Year == 1980);


%%%%%%%%%%%%%%%%%%%%%
% Figure 5
figure('Name', 'Figure 5');
set(gcf, 'Color', 'w', 'Position', [171.4000 564.2000 1116 326.4000]);
subplot(1, 2, 1);
pie([SOI_Receipts.S_Corps(Target_year_position), SOI_Receipts.Partnership(Target_year_position), SOI_Receipts.Nonfarm_SoleProp(Target_year_position), SOI_Receipts.C_Corps(Target_year_position)], labels);
colormap(mymap)
title('(a) Economic Activity in 2017');


subplot(1, 2, 2)
hold on
plot(SOI_Receipts.Year, SOI_Receipts.C_Corps_Share, '-', 'Color', Color.blue, 'LineWidth', 1.5);
plot(SOI_Receipts.Year(1:Official_data_start-1), SOI_Receipts.C_Corps_Share(1:Official_data_start-1), '-+', 'Color', Color.blue, 'LineWidth', 1.5);
plot(SOI_Receipts.Year(Official_data_start:end), SOI_Receipts.C_Corps_Share(Official_data_start:end), '-o', 'Color', Color.blue,  'LineWidth', 1.5);
plot(SOI_Receipts.Year(Target_year_position), SOI_Receipts.C_Corps_Share(Target_year_position), 'o', 'Color', Color.red, 'MarkerFaceColor', Color.red, 'LineWidth', 1.5);
box on, grid
title('(b) C-Corps Share of Economic Activity');
ytickformat('percentage');
xlabel('Year', 'FontWeight', 'bold');
ylabel('Share', 'FontWeight', 'bold');


% Autocorrelation of c-corps share
c_corps_share_persistence =  autocorr(SOI_Receipts.C_Corps_Share);
display(strcat('Autocorrelation of c-corps share =', num2str(c_corps_share_persistence(2))))
