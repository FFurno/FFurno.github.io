%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 2
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: R2020a, R2020b

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Ops
clear, clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Import Data
addpath('./Inputs/');
addpath('./Tools/');
SPF_Y = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'SPF_Y');
SPF_C = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'SPF_C');
SPF_E = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'SPF_E');
SPF_NRI = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'SPF_NRI');
SPF_I = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'SPF_I');
CBO = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'CBO');
ACTUALS = readtable('./Inputs/Macro_Forecasts.xlsx', 'sheet', 'ACTUALS');
REPATRIATION = readtimetable('./Inputs/Repatriated_Profit.xlsx', 'sheet', 'Formatted');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Repatriation from quarterly to annual
REPATRIATION = retime(REPATRIATION, 'yearly', 'sum');

% Re-Scaling
REPATRIATION.Repatriated_Profit_Scaled = REPATRIATION.Repatriated_Profit - mean(REPATRIATION.Repatriated_Profit(11:18));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creating ACTUAL Investment as sum of res + non-res
ACTUALS.I = ACTUALS.I_NR + ACTUALS.I_R;

% Change Time Variable of ACTUALS
Time = datetime([ACTUALS.YEAR, ones(size(ACTUALS.YEAR)), ones(size(ACTUALS.YEAR))]);
ACTUALS = addvars(ACTUALS, Time, 'Before', 'YEAR');
ACTUALS = table2timetable(ACTUALS);
clear Time



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change Time Variable of CBO Projections
Time = datetime([CBO.YEAR, ones(size(CBO.YEAR)), ones(size(CBO.YEAR))]);
CBO = addvars(CBO, Time, 'Before', 'YEAR');
CBO = table2timetable(CBO);
clear Time



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change Time Variable of Each SPF Variable

% Output
Time = datetime([SPF_Y.YEAR, 3 * (SPF_Y.QUARTER - 1) + 1, ones(size(SPF_Y.YEAR))]);
SPF_Y = addvars(SPF_Y, Time, 'Before', 'YEAR');
SPF_Y = table2timetable(SPF_Y);
clear Time

% Consumption
Time = datetime([SPF_C.YEAR, 3 * (SPF_C.QUARTER - 1) + 1, ones(size(SPF_C.YEAR))]);
SPF_C = addvars(SPF_C, Time, 'Before', 'YEAR');
SPF_C = table2timetable(SPF_C);
clear Time

% Employment
Time = datetime([SPF_E.YEAR, 3 * (SPF_E.QUARTER - 1) + 1, ones(size(SPF_E.YEAR))]);
SPF_E = addvars(SPF_E, Time, 'Before', 'YEAR');
SPF_E = table2timetable(SPF_E);
clear Time


% Non-Residential Investment
Time = datetime([SPF_NRI.YEAR, 3 * (SPF_NRI.QUARTER - 1) + 1, ones(size(SPF_NRI.YEAR))]);
SPF_NRI = addvars(SPF_NRI, Time, 'Before', 'YEAR');
SPF_NRI = table2timetable(SPF_NRI);
clear Time


% Investment
Time = datetime([SPF_I.YEAR, 3 * (SPF_I.QUARTER - 1) + 1, ones(size(SPF_I.YEAR))]);
SPF_I = addvars(SPF_I, Time, 'Before', 'YEAR');
SPF_I = table2timetable(SPF_I);
clear Time




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TCJA-17

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Timing of Forecasts
Forecast_Quarter = 3; 
Forecast_Year = 2017;
Year_Span = (Forecast_Year-1 : 1 : Forecast_Year+2)';

% Pre-Allocation TCJA_17 (table with timetables as content)
TCJA_17_MACRO.Y = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_MACRO.C = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_MACRO.E = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_MACRO.I_NR = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_MACRO.I = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_MACRO.T_pi = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1) GDP 

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).Y;
Forecast = SPF_Y(datetime(Forecast_Year, 3 * (Forecast_Quarter - 1) + 1, 1), 3 : 5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.Y = addvars(TCJA_17_MACRO.Y, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
TCJA_17_MACRO.Y.Actual = TCJA_17_MACRO.Y.Actual / TCJA_17_MACRO.Y.Actual(2) * 100;
TCJA_17_MACRO.Y.Forecast = TCJA_17_MACRO.Y.Forecast / TCJA_17_MACRO.Y.Forecast(2) * 100;
clear Actual Forecast


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2) Consumption 

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).C;
Forecast = SPF_C(datetime(Forecast_Year, 3 * (Forecast_Quarter - 1) + 1, 1), 3 : 5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.C = addvars(TCJA_17_MACRO.C, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
TCJA_17_MACRO.C.Actual = TCJA_17_MACRO.C.Actual / TCJA_17_MACRO.C.Actual(2) * 100;
TCJA_17_MACRO.C.Forecast = TCJA_17_MACRO.C.Forecast / TCJA_17_MACRO.C.Forecast(2) * 100;
clear Actual Forecast


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3) Employment

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).E;
Forecast = SPF_E(datetime(Forecast_Year, 3 * (Forecast_Quarter - 1) + 1, 1), 3 : 5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.E = addvars(TCJA_17_MACRO.E, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
TCJA_17_MACRO.E.Actual = TCJA_17_MACRO.E.Actual / TCJA_17_MACRO.E.Actual(2) * 100;
TCJA_17_MACRO.E.Forecast = TCJA_17_MACRO.E.Forecast / TCJA_17_MACRO.E.Forecast(2) * 100;
clear Actual Forecast


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4) Non-Residential Investment

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).I_NR;
Forecast = SPF_NRI(datetime(Forecast_Year, 3 * (Forecast_Quarter - 1) + 1, 1), 3 : 5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.I_NR = addvars(TCJA_17_MACRO.I_NR, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
TCJA_17_MACRO.I_NR.Actual = TCJA_17_MACRO.I_NR.Actual / TCJA_17_MACRO.I_NR.Actual(2) * 100;
TCJA_17_MACRO.I_NR.Forecast = TCJA_17_MACRO.I_NR.Forecast / TCJA_17_MACRO.I_NR.Forecast(2) * 100;
clear Actual Forecast



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5) Investment (Non-Residential + Residential)

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).I;
Forecast = SPF_I(datetime(Forecast_Year, 3 * (Forecast_Quarter - 1) + 1, 1), 3 : 5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.I = addvars(TCJA_17_MACRO.I, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
TCJA_17_MACRO.I.Actual = TCJA_17_MACRO.I.Actual / TCJA_17_MACRO.I.Actual(2) * 100;
TCJA_17_MACRO.I.Forecast = TCJA_17_MACRO.I.Forecast / TCJA_17_MACRO.I.Forecast(2) * 100;
clear Actual Forecast


%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 6) Corporate Tax Revenues

% Auxiliary Vars
Actual = ACTUALS(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))), :).T_pi;
Forecast = CBO(datetime(Forecast_Year, 1, 1), 3:5);
Forecast = [nan; Forecast{1, :}'];

% Table Finalization + Re-Scaling
TCJA_17_MACRO.T_pi = addvars(TCJA_17_MACRO.T_pi, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});
Actual_aux = TCJA_17_MACRO.T_pi.Actual;
Actual_aux_adjusted = (TCJA_17_MACRO.T_pi.Actual - 0.15 *([0; 0; REPATRIATION.Repatriated_Profit_Scaled(19:20)] / 1e3) );
TCJA_17_MACRO.T_pi.Actual = Actual_aux / Actual_aux(2) * 100;
TCJA_17_MACRO.T_pi.Actual_Adjusted = Actual_aux_adjusted / Actual_aux_adjusted(2) * 100;
TCJA_17_MACRO.T_pi.Forecast = TCJA_17_MACRO.T_pi.Forecast / TCJA_17_MACRO.T_pi.Forecast(2) * 100;
clear Actual Forecast Actual_aux





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time Frame for Forecast Errors 
% Note: SPF Forecasts are taken according to "Forecast_Quarter" variable

% Max Out Available Info
t_begin = 2011;
t_end = 2018;

% Preparing Actuals for Extraction
ACTUALS_Y = ACTUALS(:, 2);
ACTUALS_C = ACTUALS(:, 3);
ACTUALS_E = ACTUALS(:, 4);
ACTUALS_INR = ACTUALS(:, 6); 
ACTUALS_Tpi = ACTUALS(:, 7);
ACTUALS_I = ACTUALS(:, 8);


% Preparing Data for FE Computation          
FE_Input.Y = FE_Input_Auxiliary_SPF(t_begin, t_end, Forecast_Quarter, ACTUALS_Y, SPF_Y);
FE_Input.C = FE_Input_Auxiliary_SPF(t_begin, t_end, Forecast_Quarter, ACTUALS_C, SPF_C);
FE_Input.E = FE_Input_Auxiliary_SPF(t_begin, t_end, Forecast_Quarter, ACTUALS_E, SPF_E);
FE_Input.I_NR = FE_Input_Auxiliary_SPF(t_begin, t_end, Forecast_Quarter, ACTUALS_INR, SPF_NRI);
FE_Input.I = FE_Input_Auxiliary_SPF(t_begin, t_end, Forecast_Quarter, ACTUALS_I, SPF_I);
FE_Input.T_pi = FE_Input_Auxiliary_CBO(t_begin, t_end, ACTUALS_Tpi, CBO);

% FE Computation
FE_Store.Y = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.Y);
FE_Store.C = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.C);
FE_Store.E = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.E);
FE_Store.I_NR = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.I_NR);
FE_Store.I = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.I);
FE_Store.T_pi = FE_Computation_Auxiliary(t_begin, t_end, FE_Input.T_pi);


% Kernel Distribution Params
Kernel_Bandwith = 1;
Mass_Center = 0.68;





%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adding Upper and Lower Bounds

% Output
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.Y.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.Y.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.Y.Forecast_lb = [nan, 100, TCJA_17_MACRO.Y.Forecast(3) + lb_1_aux, TCJA_17_MACRO.Y.Forecast(4) + lb_2_aux]';
TCJA_17_MACRO.Y.Forecast_ub = [nan, 100, TCJA_17_MACRO.Y.Forecast(3) + ub_1_aux, TCJA_17_MACRO.Y.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux



% Consumption
[lb_aux, ub_aux] = FE_Kernel_Percentiles_Aux(FE_Store.C.FE1, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.C.Forecast_lb = [nan, 100, TCJA_17_MACRO.C.Forecast(3) + lb_aux, nan]';
TCJA_17_MACRO.C.Forecast_ub = [nan, 100, TCJA_17_MACRO.C.Forecast(3) + ub_aux, nan]';
clear lb_aux ub_aux


% Employment
[lb_aux, ub_aux] = FE_Kernel_Percentiles_Aux(FE_Store.E.FE1, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.E.Forecast_lb = [nan, 100, TCJA_17_MACRO.E.Forecast(3) + lb_aux, nan]';
TCJA_17_MACRO.E.Forecast_ub = [nan, 100, TCJA_17_MACRO.E.Forecast(3) + ub_aux, nan]';
clear lb_aux ub_aux


% Investment
[lb_aux, ub_aux] = FE_Kernel_Percentiles_Aux(FE_Store.I.FE1, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.I.Forecast_lb = [nan, 100, TCJA_17_MACRO.I.Forecast(3) + lb_aux, nan]';
TCJA_17_MACRO.I.Forecast_ub = [nan, 100, TCJA_17_MACRO.I.Forecast(3) + ub_aux, nan]';
clear lb_aux ub_aux

% Non-Residential Investment
[lb_aux, ub_aux] = FE_Kernel_Percentiles_Aux(FE_Store.I_NR.FE1, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.I_NR.Forecast_lb = [nan, 100, TCJA_17_MACRO.I_NR.Forecast(3) + lb_aux, nan]';
TCJA_17_MACRO.I_NR.Forecast_ub = [nan, 100, TCJA_17_MACRO.I_NR.Forecast(3) + ub_aux, nan]';
clear lb_aux ub_aux


% Corporate Tax Revenues
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.T_pi.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.T_pi.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_MACRO.T_pi.Forecast_lb = [nan, 100, TCJA_17_MACRO.T_pi.Forecast(3) + lb_1_aux, TCJA_17_MACRO.T_pi.Forecast(4) + lb_2_aux]';
TCJA_17_MACRO.T_pi.Forecast_ub = [nan, 100, TCJA_17_MACRO.T_pi.Forecast(3) + ub_1_aux, TCJA_17_MACRO.T_pi.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux




%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Settings
Color_actuals = [0, 0.4470, 0.7410];
Color_forecasts = [0.8500, 0.3250, 0.0980];
Bands_alpha = 0.25;
x_axis = 2016:2019;


%%%%%%
% Figure 2
figure('Name', 'Figure 2');
set(gcf, 'Color', 'w', 'Position', [89.8000 405 1.4112e+03 596.8000]);
subplot(2, 3, 1)
hold on
plot_actual = plot(x_axis, TCJA_17_MACRO.Y.Actual, '-o', 'LineWidth', 1.5);
plot_forecast = plot(x_axis, TCJA_17_MACRO.Y.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot_bands = confidence_bands(x_axis, TCJA_17_MACRO.Y.Forecast_lb, TCJA_17_MACRO.Y.Forecast_ub, Color_forecasts, Bands_alpha);  
hold off
ylim([95, 110]);
box on, grid;
title('GDP');
xticks(x_axis);
legend([plot_actual, plot_forecast, plot_bands(2)], 'Actual', 'Forecast', 'FE Distribution', 'Location', 'northwest');


subplot(2, 3, 2)
hold on
plot(x_axis, TCJA_17_MACRO.C.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_MACRO.C.Forecast_lb, TCJA_17_MACRO.C.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_MACRO.C.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
ylim([95, 110]);
box on, grid;
title('Consumption');
xticks(x_axis);


subplot(2, 3, 3)
hold on
plot(x_axis, TCJA_17_MACRO.E.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_MACRO.E.Forecast_lb, TCJA_17_MACRO.E.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_MACRO.E.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([95, 110]);
box on, grid;
title('Employment');
xticks(x_axis);



subplot(2, 3, 4)
hold on
plot(x_axis, TCJA_17_MACRO.I.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_MACRO.I.Forecast_lb, TCJA_17_MACRO.I.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_MACRO.I.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([95, 115]);
box on, grid;
title('Investment');
xticks(x_axis);




subplot(2, 3, 5)
hold on
plot(x_axis, TCJA_17_MACRO.I_NR.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_MACRO.I_NR.Forecast_lb, TCJA_17_MACRO.I_NR.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_MACRO.I_NR.Forecast, '-o', 'Color', Color_forecasts,  'LineWidth', 1.5);
hold off
ylim([95, 115]);
box on, grid;
title('Non-Residential Investment');
xticks(x_axis);



subplot(2, 3, 6)
hold on
plot(x_axis, TCJA_17_MACRO.T_pi.Actual, '-o', 'LineWidth', 1.5);
adjusted_actual_plot = plot(x_axis, TCJA_17_MACRO.T_pi.Actual_Adjusted, '--o', 'Color', Color_actuals, 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_MACRO.T_pi.Forecast_lb, TCJA_17_MACRO.T_pi.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_MACRO.T_pi.Forecast, '-o', 'Color', Color_forecasts,  'LineWidth', 1.5);
hold off
ylim([20, 120]);
box on, grid;
title('Corporate Tax Revenues');
xticks(x_axis);
legend([adjusted_actual_plot], 'Without Repatriation', 'Location', 'southwest');




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bonus Figure - Repatriated Earnings
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [407.40 533.00 1056.80 348.80]);
subplot(1, 2, 1)
bar(REPATRIATION.Year(11:end-1), REPATRIATION.Repatriated_Profit(11:end-1) / 1e3);
ylim([-100, 1000]);
xlabel('Year');
ylabel('Amount ($bln)');
title('Repatriated Earnings');
box on, grid;

subplot(1, 2, 2)
bar(REPATRIATION.Year(11:end-1), REPATRIATION.Repatriated_Profit_Scaled(11:end-1) / 1e3);
ylim([-100, 1000]);
xlabel('Year');
ylabel('Amount ($bln)');
title('Repatriated Earnings - Scaled');
box on, grid;

