%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 12
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;
addpath(genpath('./Tools/'));



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model - 1961 vs 2017 Counterfactuals

%%%%%%%%%%%%%
% 1) Economy in 1961
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.70);
set_param_value('delta_pi_before', 0.10);
set_param_value('delta_pi_after', 0.10);
steady;
[Kennedy_level_extended, Kennedy_extended] = Transition_extractor([0.52, 0], [0.52-0.10, 1], 10000);
[Kennedy_level_extended, Kennedy_extended] = Transition_additional_vars_aux(Kennedy_level_extended, Kennedy_extended);


%%%%%%%%%%%%%
% 2) Economy in 2017
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.55);
set_param_value('delta_pi_before', 0.4823);
set_param_value('delta_pi_after', 0.4823);
steady;
[Trump_level_extended, Trump_extended] = Transition_extractor([0.35, 0], [0.35-0.10, 1], 10000);
[Trump_level_extended, Trump_extended] = Transition_additional_vars_aux(Trump_level_extended, Trump_extended);



%%%%%%%%%%%%%
% 3) Economy in 2017 with 1961 Tax Depreciation 
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.55);
set_param_value('delta_pi_before', 0.10);
set_param_value('delta_pi_after', 0.10);
steady;
[Trump_level_depreciation, Trump_depreciation] = Transition_extractor([0.35, 0], [0.35-0.10, 1], 10000);
[Trump_level_depreciation, Trump_depreciation] = Transition_additional_vars_aux(Trump_level_depreciation, Trump_depreciation);



%%%%%%%%%%%%%
% 4) Economy in 2017 with 1961 Tax Rate
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.55);
set_param_value('delta_pi_before', 0.4823);
set_param_value('delta_pi_after', 0.4823);
steady;
[Trump_level_rate, Trump_rate] = Transition_extractor([0.52, 0], [0.52-0.10, 1], 10000);
[Trump_level_rate, Trump_rate] = Transition_additional_vars_aux(Trump_level_rate, Trump_rate);



%%%%%%%%%%%%%
% 5) Economy in 2017 with 1961 Pass-Through Share
dynare Dynare_Model_Extended
set_param_value('gamma_CES', 0.70);
set_param_value('delta_pi_before', 0.4823);
set_param_value('delta_pi_after', 0.4823);
steady;steady;
[Trump_level_PT, Trump_PT] = Transition_extractor([0.35, 0], [0.35-0.10, 1], 10000);
[Trump_level_PT, Trump_PT] = Transition_additional_vars_aux(Trump_level_PT, Trump_PT);


%%%%%%%%%%%%
% Cleaning Temp Files
clean_dynare_output('Dynare_Model_Extended');



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Additional Calculations 

% Computation Horizon
horizon_years = 20;
horizon_index = 1 + horizon_years;

% Variable Preparation
X = categorical({'GDP', 'Investment', 'Payouts'});
X = reordercats(X,{'GDP', 'Investment', 'Payouts'});


%%%%%%%%%
% Percentage Deviations from Steady-State
Cumulative_Deviation_1961 = [(sum(Kennedy_level_extended.Y_Aggregate_Real(1:horizon_index)) ./ (Kennedy_level_extended.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Kennedy_level_extended.I_Aggregate_Real(1:horizon_index)) ./ (Kennedy_level_extended.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Kennedy_level_extended.D_Corp(1:horizon_index)) ./ (Kennedy_level_extended.D_Corp(1) * horizon_index) - 1) * 100];

Cumulative_Deviation_2017 = [(sum(Trump_level_extended.Y_Aggregate_Real(1:horizon_index)) ./ (Trump_level_extended.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Trump_level_extended.I_Aggregate_Real(1:horizon_index)) ./ (Trump_level_extended.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Trump_level_extended.D_Corp(1:horizon_index)) ./ (Trump_level_extended.D_Corp(1) * horizon_index) - 1) * 100];

        
Cumulative_Deviation_2017_depreciation = [(sum(Trump_level_depreciation.Y_Aggregate_Real(1:horizon_index)) ./ (Trump_level_depreciation.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Trump_level_depreciation.I_Aggregate_Real(1:horizon_index)) ./ (Trump_level_depreciation.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Trump_level_depreciation.D_Corp(1:horizon_index)) ./ (Trump_level_depreciation.D_Corp(1) * horizon_index) - 1) * 100];
        
        
Cumulative_Deviation_2017_rate = [(sum(Trump_level_rate.Y_Aggregate_Real(1:horizon_index)) ./ (Trump_level_rate.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Trump_level_rate.I_Aggregate_Real(1:horizon_index)) ./ (Trump_level_rate.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Trump_level_rate.D_Corp(1:horizon_index)) ./ (Trump_level_rate.D_Corp(1) * horizon_index) - 1) * 100];


Cumulative_Deviation_2017_PT = [(sum(Trump_level_PT.Y_Aggregate_Real(1:horizon_index)) ./ (Trump_level_PT.Y_Aggregate_Real(1) * horizon_index) - 1) * 100 ,  ...
            (sum(Trump_level_PT.I_Aggregate_Real(1:horizon_index)) ./ (Trump_level_PT.I_Aggregate_Real(1) * horizon_index) - 1) * 100,  ...
            (sum(Trump_level_PT.D_Corp(1:horizon_index)) ./ (Trump_level_PT.D_Corp(1) * horizon_index) - 1) * 100];

                

%%%%%%%%%
% Computing Multipliers
[~, Cumulative_Multiplier_1961] = Multiplier_aux(Kennedy_level_extended);
[~, Cumulative_Multiplier_2017] = Multiplier_aux(Trump_level_extended);
[~, Cumulative_Multiplier_2017_depreciation] = Multiplier_aux(Trump_level_depreciation);
[~, Cumulative_Multiplier_2017_rate] = Multiplier_aux(Trump_level_rate);
[~, Cumulative_Multiplier_2017_PT] = Multiplier_aux(Trump_level_PT);



Multiplier_1961 = [-Cumulative_Multiplier_1961.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_1961.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_1961.D_Corp(horizon_index)];

Multiplier_2017 = [-Cumulative_Multiplier_2017.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017.D_Corp(horizon_index)];

Multiplier_2017_depreciation = [-Cumulative_Multiplier_2017_depreciation.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_depreciation.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_depreciation.D_Corp(horizon_index)];

Multiplier_2017_rate = [-Cumulative_Multiplier_2017_rate.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_rate.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_rate.D_Corp(horizon_index)];

Multiplier_2017_PT = [-Cumulative_Multiplier_2017_PT.Y_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_PT.I_Aggregate_Real(horizon_index),  ...
            -Cumulative_Multiplier_2017_PT.D_Corp(horizon_index)];

        
%%%%%%%%%%%%%%%%%%%%%%%%%%       
% Visualization Parameters
Color1 = [0, 0.4470, 0.7410];
Color2 = [0.8500, 0.3250, 0.0980];
Color3 = [0.9290, 0.6940, 0.1250];
Color4 = [0.4660, 0.6740, 0.1880];
Color5 = [0.4940, 0.1840, 0.5560];



%%%%%%%%%%%%%%%%
% Group = Macro Variable
% Stacks per Group = Number of Reforms Considered
% Stack Elements = Number of Counterfactuals per Reform
NumGroupsPerAxis = 3; NumStacksPerGroup = 2; NumStackElements = 4;
groupLabels = { 'GDP'; 'Investment'; 'Payouts'}; % labels to use on tick marks for groups
stackData_Deviation = zeros(NumGroupsPerAxis,NumStacksPerGroup,NumStackElements);
stackData_Deviation(:, :, 1) = [Cumulative_Deviation_2017', Cumulative_Deviation_1961'];
stackData_Deviation(:, :, 2) = [ (Cumulative_Deviation_2017_depreciation' - Cumulative_Deviation_2017'), zeros(size(Cumulative_Deviation_1961'))];
stackData_Deviation(:, :, 3) = [ (Cumulative_Deviation_2017_rate' - Cumulative_Deviation_2017'), zeros(size(Cumulative_Deviation_1961'))];
stackData_Deviation(:, :, 4) = [ (Cumulative_Deviation_2017_PT' - Cumulative_Deviation_2017'), zeros(size(Cumulative_Deviation_1961'))];

stackData_Multiplier = zeros(NumGroupsPerAxis,NumStacksPerGroup,NumStackElements);
stackData_Multiplier(:, :, 1) = [Multiplier_2017', Multiplier_1961'];
stackData_Multiplier(:, :, 2) = [ (Multiplier_2017_depreciation' - Multiplier_2017'), zeros(size(Multiplier_1961'))];
stackData_Multiplier(:, :, 3) = [ (Multiplier_2017_rate' - Multiplier_2017'), zeros(size(Multiplier_1961'))];
stackData_Multiplier(:, :, 4) = [ (Multiplier_2017_PT' - Multiplier_2017'), zeros(size(Multiplier_1961'))];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 12
figure('Name', 'Figure 12');
set(gcf, 'Color', 'w', 'Position', [353.8000 545 1.1048e+03 357.6000]);


%%%%%%%%%%%%%%%%%%
% 1) Cumulative Deviation from SS
subplot(1, 2, 1)
H = plotBarStackGroups(stackData_Deviation, groupLabels);
set(H(1, 1), 'FaceColor', Color1);
set(H(2, 1), 'FaceColor', Color2);
set(H(1, 2), 'FaceColor', Color3);
set(H(2, 2), 'FaceColor', Color2);
set(H(1, 3), 'FaceColor', Color4);
set(H(2, 3), 'FaceColor', Color2);
set(H(1, 4), 'FaceColor', Color5);
set(H(2, 4), 'FaceColor', Color2);
box on;
legend([H(1,1), H(2,1), H(1,2), H(1,3), H(1, 4)], '2017', '1961', '2017 w/ Tax Depr 1961', ...
    '2017 w/ Tax Rate 1961', '2017 w/ Pass-Through 1961', 'Location', 'southwest', 'FontSize', 8);
title('Long-Run Change');
ylabel('20-Year Cumulative Change');
ytickformat('percentage');

% Labels for 2017
xpos = H(1, 1).XData;
ypos = H(1, 1).YData + H(1, 2).YData + H(1, 3).YData + H(1, 4).YData;
yvalues = ypos;
hhtext = text(xpos(1:3), ypos(1:3), {num2str(round(yvalues(1), 2)); num2str(round(yvalues(2), 2)); num2str(round(yvalues(3), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')

% Labels for 1961
hhtext = text(H(2,1).XData(1:2), H(2,1).YData(1:2), {num2str(round(H(2,1).YData(1), 2)); num2str(round(H(2,1).YData(2), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')
hhhtext = text(H(2,1).XData(3), H(2,1).YData(3), num2str(round(H(2,1).YData(3), 2))); 
set(hhhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')


%%%%%%%%%%%%%%%%%%
% 2) Corporate Tax Multiplier
subplot(1, 2, 2)
H = plotBarStackGroups(stackData_Multiplier, groupLabels);
set(H(1, 1), 'FaceColor', Color1);
set(H(2, 1), 'FaceColor', Color2);
set(H(1, 2), 'FaceColor', Color3);
set(H(2, 2), 'FaceColor', Color2);
set(H(1, 3), 'FaceColor', Color4);
set(H(2, 3), 'FaceColor', Color2);
set(H(1, 4), 'FaceColor', Color5);
set(H(2, 4), 'FaceColor', Color2);
box on;
title('Corporate Tax Multiplier');
ylabel('20-Year Cumulative Multiplier');
ylim([-1, 3]);

% Labels for 2017
xpos = H(1, 1).XData;
ypos = H(1, 1).YData + H(1, 2).YData + H(1, 3).YData + H(1, 4).YData; 
yvalues = ypos;
hhtext = text(xpos(1:3), ypos(1:3), {num2str(round(yvalues(1), 2)); num2str(round(yvalues(2), 2)); num2str(round(yvalues(3), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')

% Labels for 1961
hhtext = text(H(2,1).XData(1:2), H(2,1).YData(1:2), {num2str(round(H(2,1).YData(1), 2)); num2str(round(H(2,1).YData(2), 2))});    
set(hhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')
hhhtext = text(H(2,1).XData(3), H(2,1).YData(3), num2str(round(H(2,1).YData(3), 2))); 
set(hhhtext,'VerticalAlignment','bottom', 'HorizontalAlignment','center')

