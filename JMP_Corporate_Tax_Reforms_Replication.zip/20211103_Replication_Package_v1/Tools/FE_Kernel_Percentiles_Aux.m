function [lb_out, ub_out] = FE_Kernel_Percentiles_Aux(FE_Store_X, Kernel_Bandwith, Mass_Center)

if (Mass_Center > 1 || Mass_Center < 0)
    error('Mass_Center should be between 0 and 1')
end


[kernel_pdf, support] = ksdensity(FE_Store_X, 'Bandwidth',  Kernel_Bandwith, 'Kernel', 'normal'); 
aux = randsample(support, 1e6 , true, kernel_pdf);

percentile_low = 100 * (0.5 - Mass_Center / 2);
percentile_high = 100 * (0.5 + Mass_Center / 2);

lb_out = prctile(aux, percentile_low);
ub_out = prctile(aux, percentile_high);



end
