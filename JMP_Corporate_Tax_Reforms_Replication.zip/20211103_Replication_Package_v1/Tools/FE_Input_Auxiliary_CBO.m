function FE_Input_out = FE_Input_Auxiliary_CBO(t_begin, t_end, ACTUALS_X, CBO)
% Function prepares data for FE_Computation_Auxiliary

t_span_input = (t_begin : 1 : t_end+2)';
FE_Input_out = timetable(datetime(t_span_input, ones(size(t_span_input)), ones(size(t_span_input))));

Actual = ACTUALS_X(datetime(t_span_input, ones(size(t_span_input)), ones(size(t_span_input))), :);
Actual = [Actual{:, :}];

Forecast_t0 = CBO(datetime(t_span_input, 1, 1), :).FORECAST_T0;
Forecast_t1 = CBO(datetime(t_span_input, 1, 1), :).FORECAST_T1;
Forecast_t2 = CBO(datetime(t_span_input, 1, 1), :).FORECAST_T2;
FE_Input_out = addvars(FE_Input_out, Actual, Forecast_t0, Forecast_t1, Forecast_t2, ...
                'NewVariableNames', {'Actual','Forecast_t0', 'Forecast_t1', 'Forecast_t2'});


end
