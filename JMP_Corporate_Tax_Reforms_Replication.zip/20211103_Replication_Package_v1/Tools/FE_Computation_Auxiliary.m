function FE_Store_out = FE_Computation_Auxiliary(t_begin, t_end, Input_TimeTable)
% Function takes an initial time and an end time and computes FEs. Inputs
% need to be arranged according to the FE_Input functions.


t_span_store =  (t_begin : 1 : t_end)';
FE_Store_out = timetable(datetime(t_span_store, ones(size(t_span_store)), ones(size(t_span_store))));


FE1 = zeros(size(t_span_store));
FE2 = zeros(size(t_span_store));
Actual1 = zeros(size(t_span_store));
Actual2 = zeros(size(t_span_store));
Forecast1 = zeros(size(t_span_store));
Forecast2 = zeros(size(t_span_store));
FE_Store_out = addvars(FE_Store_out, FE1, FE2, Actual1, Forecast1, Actual2, Forecast2, ...
                'NewVariableNames', {'FE1','FE2', 'Actual1', 'Forecast1', 'Actual2', 'Forecast2'});


for index  = 1 : length(t_span_store)
    
    % Auxiliary Time Indeces
    t_index = t_span_store(index);
    aux_date = datetime(t_index, 1, 1);
    aux_date1 = datetime(t_index + 1, 1, 1);
    aux_date2 = datetime(t_index + 2, 1, 1);
    
    % Scaled Values 
    Year_aux.Actual_1_scaled = Input_TimeTable(aux_date1, :).Actual / Input_TimeTable(aux_date, :).Actual * 100;
    Year_aux.Actual_2_scaled = Input_TimeTable(aux_date2, :).Actual / Input_TimeTable(aux_date, :).Actual * 100;
    Year_aux.Forecast_1_scaled = Input_TimeTable(aux_date, :).Forecast_t1 / Input_TimeTable(aux_date, :).Forecast_t0  * 100;
    Year_aux.Forecast_2_scaled = Input_TimeTable(aux_date, :).Forecast_t2 / Input_TimeTable(aux_date, :).Forecast_t0  * 100;
    
    % Actuals, Forecasts, Forecast Errors
    FE_Store_out{index, 1} = Year_aux.Actual_1_scaled - Year_aux.Forecast_1_scaled;
    FE_Store_out{index, 2} = Year_aux.Actual_2_scaled - Year_aux.Forecast_2_scaled;
    FE_Store_out{index, 3} = Year_aux.Actual_1_scaled;
    FE_Store_out{index, 4} = Year_aux.Forecast_1_scaled;
    FE_Store_out{index, 5} = Year_aux.Actual_2_scaled;
    FE_Store_out{index, 6} = Year_aux.Forecast_2_scaled;
end



end

