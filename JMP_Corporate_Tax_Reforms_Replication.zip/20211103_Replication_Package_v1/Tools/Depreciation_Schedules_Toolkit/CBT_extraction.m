function country_year = CBT_extraction(CBT, country, year)
% Author: Francesco Furno
% Created: 20 February 2020
% Last Revision: 05 February 2021
% Input: CBT dataset as a table, country code as string, year as number
% Sub-Functions: Depreciation Schedule Generators
% Depreciation Schedules Allowed: SL, DB, SL2, DBSL, initialDB

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Creating Auxiliary Country-Year Object Containing Info
entry_aux = CBT(CBT.country == country & CBT.year == year, :);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% First: Structures (or Buildings)
if entry_aux.taxdepbuildtype == 'SL'
    % Auxiliary
    J_structures  = entry_aux.taxdeprbuildtimesl;
    % Out
    country_year.structures = SL_depreciation(J_structures);
    country_year.structures_type = 'SL';
    country_year.structure_recovery_rate = sum(country_year.structures);

    
elseif entry_aux.taxdepbuildtype == 'DB'
    % Auxiliary
    delta_pi_structures = entry_aux.taxdeprbuilddb;
    % Out
    country_year.structures = DB_depreciation(delta_pi_structures);
    country_year.structures_type = 'DB';
    country_year.structure_recovery_rate = sum(country_year.structures);

    
elseif entry_aux.taxdepbuildtype == 'DB or SL'
    % Auxiliary
    delta_db_structures = entry_aux.taxdeprbuilddb;
    delta_sl_structures = entry_aux.taxdeprbuildsl;
    T_db_structures = entry_aux.taxdeprbuildtimedb;
    T_sl_structures = entry_aux.taxdeprbuildtimesl;
    % Out
    country_year.structures = DBSL_depreciation(delta_db_structures, delta_sl_structures, T_db_structures, T_sl_structures);
    country_year.structures_type = 'DB with change to SL';
    country_year.structure_recovery_rate = sum(country_year.structures);

    
elseif entry_aux.taxdepbuildtype == 'SL2'
    % Auxiliary
    rate_1_structure = entry_aux.taxdeprbuilddb;
    rate_2_structure = entry_aux.taxdeprbuildsl;
    T_1_structure = entry_aux.taxdeprbuildtimedb;
    T_2_structure = entry_aux.taxdeprbuildtimesl;
    % Out
    country_year.structures = SL2_depreciation(rate_1_structure, rate_2_structure, T_1_structure, T_2_structure);
    country_year.structures_type = 'SL with 2 rates';
    country_year.structure_recovery_rate = sum(country_year.structures);


elseif entry_aux.taxdepbuildtype == 'initialDB'
    % Auxiliary
    rate_1_structure = entry_aux.taxdeprbuilddb;
    rate_2_structure = entry_aux.taxdeprbuildsl;
    % Out
    country_year.structures = initialDB_depreciation(rate_1_structure, rate_2_structure);
    country_year.structures_type = 'DB with initial allowance';
    country_year.structure_recovery_rate = sum(country_year.structures);


elseif ismissing(entry_aux.taxdepbuildtype) == 1
    % Out
    country_year.stuctures = 'No Data';
    
else
    disp(entry_aux.taxdepbuildtype)
    error('Unrecognized Structures Depreciation Type')
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Second: Machinery
if entry_aux.taxdepmachtype == 'SL'
    % Auxiliary
    J_machinery  = entry_aux.taxdepmachtimesl;
    % Out
    country_year.machinery = SL_depreciation(J_machinery);
    country_year.machinery_type = 'SL';
    country_year.machinery_recovery_rate = sum(country_year.machinery);

    
elseif entry_aux.taxdepmachtype == 'DB'
    % Auxiliary
    delta_pi_machinery = entry_aux.taxdeprmachdb;
    % Out
    country_year.machinery= DB_depreciation(delta_pi_machinery);
    country_year.machinery_type = 'DB';
    country_year.machinery_recovery_rate = sum(country_year.machinery);


elseif entry_aux.taxdepmachtype == 'DB or SL'
    % Auxiliary
    delta_db_machinery = entry_aux.taxdeprmachdb;
    delta_sl_machinery = entry_aux.taxdeprmachsl;
    T_db_machinery = entry_aux.taxdepmachtimedb;
    T_sl_machinery = entry_aux.taxdepmachtimesl;
    % Out
    country_year.machinery = DBSL_depreciation(delta_db_machinery, delta_sl_machinery, T_db_machinery, T_sl_machinery);
    country_year.machinery_type = 'DB with change to SL';
    country_year.machinery_recovery_rate = sum(country_year.machinery);

    
elseif entry_aux.taxdepmachtype == 'SL2'
    % Auxiliary
    rate_1_machinery = entry_aux.taxdeprmachdb;
    rate_2_machinery = entry_aux.taxdeprmachsl;
    T_1_machinery = entry_aux.taxdepmachtimedb;
    T_2_machinery = entry_aux.taxdepmachtimesl;
    % Out
    country_year.machinery = SL2_depreciation(rate_1_machinery, rate_2_machinery, T_1_machinery, T_2_machinery);
    country_year.machinery_type = 'SL with 2 rates';
    country_year.machinery_recovery_rate = sum(country_year.machinery);
   

elseif entry_aux.taxdepmachtype == 'initialDB'
    % Auxiliary
    rate_1_machinery = entry_aux.taxdeprmachdb;
    rate_2_machinery = entry_aux.taxdeprmachsl;
    % Out
    country_year.machinery = initialDB_depreciation(rate_1_machinery, rate_2_machinery);
    country_year.machinery_type = 'DB with initial allowance';
    country_year.machinery_recovery_rate = sum(country_year.machinery);


elseif ismissing(entry_aux.taxdepmachtype) == 1
    % Out
    country_year.intangibles = 'No Data';

else
    disp(entry_aux.taxdepmachtype)
    error('Unrecognized Machinery Depreciation Type')
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Third: Intangible
if entry_aux.taxdepintangibltype == 'SL'
    % Auxiliary
    J_intangibles = entry_aux.taxdepintangibltimesl;
    % Out
    country_year.intangibles = SL_depreciation(J_intangibles);
    country_year.intangibles_type = 'SL';
    country_year.intangibles_recovery_rate = sum(country_year.intangibles);

    
elseif entry_aux.taxdepintangibltype == 'DB'
    % Auxiliary
    delta_pi_intangibles = entry_aux.taxdeprintangibldb;
    % Out
    country_year.intangibles = DB_depreciation(delta_pi_intangibles);
    country_year.intangibles_type = 'DB';
    country_year.intangibles_recovery_rate = sum(country_year.intangibles);
    
    
elseif entry_aux.taxdepintangibltype == 'DB or SL'
    % Auxiliary
    delta_db_intangibles = entry_aux.taxdeprintangibldb;
    delta_sl_intangibles = entry_aux.taxdeprintangiblsl;
    T_db_intangibles = entry_aux.taxdeprintangibltimedb;
    T_sl_intangibles = entry_aux.taxdeprintangibltimesl;
    % Out
    country_year.intangibles = DBSL_depreciation(delta_db_intangibles, delta_sl_intangibles, T_db_intangibles, T_sl_intangibles);
    country_year.intangibles_type = 'DB with change to SL';
    country_year.intangibles_recovery_rate = sum(country_year.intangibles);

    
elseif entry_aux.taxdepintangibltype == 'SL2'
    % Auxiliary
    rate_1_intangibles = entry_aux.taxdeprintangibldb;
    rate_2_intangibles = entry_aux.taxdeprintangiblsl;
    T_1_intangibles = entry_aux.taxdeprintangibltimedb;
    T_2_intangibles = entry_aux.taxdeprintangibltimesl;
    % Out
    country_year.intangibles = SL2_depreciation(rate_1_intangibles, rate_2_intangibles, T_1_intangibles, T_2_intangibles);
    country_year.intangibles_type = 'SL with 2 rates';
    country_year.intangibles_recovery_rate = sum(country_year.machinery);    


elseif entry_aux.taxdepintangibltype == 'initialDB'
    % Auxiliary
    rate_1_intangibles = entry_aux.taxdeprintangibldb;
    rate_2_intangibles = entry_aux.taxdeprintangiblsl;
    % Out
    country_year.intangibles = initialDB_depreciation(rate_1_intangibles, rate_2_intangibles);
    country_year.intangibles_type = 'DB with initial allowance';
    country_year.intangibles_recovery_rate = sum(country_year.intangibles);

    
elseif ismissing(entry_aux.taxdepintangibltype) == 1
    % Out
    country_year.intangibles = 'No Data';

else
    disp(entry_aux.taxdepintangibltype)
    error('Unrecognized Intangible Depreciation Type')
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%





end
