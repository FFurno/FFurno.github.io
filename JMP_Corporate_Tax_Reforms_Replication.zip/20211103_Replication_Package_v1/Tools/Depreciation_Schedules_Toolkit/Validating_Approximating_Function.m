%% Validation of the Approximation Toolkit

for index = 1 : 100
    x = SL_depreciation(index);
    HL_original(1, index) = HL_depreciation(x);
    HL_approximation(1, index) = HL_depreciation(Approximating_depreciation(x));
end
[HL_original; HL_approximation]




% Approximating a Straigh-Line Depreciation
J = 18;
x = SL_depreciation(J);
x_approx = Approximating_depreciation(x);
HL_original = HL_depreciation(x)
HL_approximation = HL_depreciation(x_approx)


figure,
hold on
bar(x)
bar(x_approx)
hold off







% Approximating a Declining-Balance Depreciation
delta_pi = 0.6;
x = DB_depreciation(delta_pi);
[x_approx, delta_approx] = Approximating_depreciation(x);

figure,
hold on
bar(x)
bar(x_approx)
hold off

beta = 0.99;
PDV_depreciation(x, beta)
PDV_depreciation(x_approx, beta)




