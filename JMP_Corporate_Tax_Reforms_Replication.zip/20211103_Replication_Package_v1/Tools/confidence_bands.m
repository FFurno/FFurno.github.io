% Francesco's Notes: this comes from Cloyne, Surico (RESTUD, 2017), modified for my purposes. 

function [ha] = confidence_bands(x, y1, y2, color, alpha_input)

% x is x-axis
% y1 is lower bound of y
% y2 is upper bound of y
% inputs as vectors

% plot the shaded area
x = x';
y1 = y1';
y2 = y2';
y = [y1; (y2-y1)]'; 
ha = area(x, y);
set(ha(1), 'FaceColor', 'none') % this makes the bottom area invisible
set(ha(2), 'FaceColor', color)
set(ha(2), 'FaceAlpha', alpha_input)
set(ha, 'LineStyle', 'none')
