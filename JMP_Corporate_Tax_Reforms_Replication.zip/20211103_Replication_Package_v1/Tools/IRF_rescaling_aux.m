function Data_scaled = IRF_rescaling_aux(Data, year)

var_list = fieldnames(Data);


for var_index = 1 : length(var_list)
    var_name_aux = var_list{var_index};
    Data_scaled.(var_name_aux).point = Data.(var_name_aux).Actual(2:end) - Data.(var_name_aux).Forecast(2:end);
    Data_scaled.(var_name_aux).lb = Data.(var_name_aux).Actual(2:end) - Data.(var_name_aux).Forecast_ub(2:end);
    Data_scaled.(var_name_aux).ub = Data.(var_name_aux).Actual(2:end) - Data.(var_name_aux).Forecast_lb(2:end);
end


Data_scaled.Year = [year : year+length(Data.(var_name_aux).Actual(2:end)) - 1];


end
