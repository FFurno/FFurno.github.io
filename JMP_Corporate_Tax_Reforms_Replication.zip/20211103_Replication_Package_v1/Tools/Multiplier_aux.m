function [Tax_Multiplier, Cumulative_Tax_Multiplier] = Multiplier_aux(Reform_level)

Multiplier_Horizon = 500;

% Corporate Tax Revenues
Revenues_scaled_aux = Reform_level.T_Corp - Reform_level.T_Corp(1); 


% Corporate Output
Tax_Multiplier.Y_Corp = ( Reform_level.Y_Corp - Reform_level.Y_Corp(1) ) ./ Revenues_scaled_aux;
Cumulative_Tax_Multiplier.Y_Corp = cumsum( ( Reform_level.Y_Corp - Reform_level.Y_Corp(1) ) ) ./ cumsum(Revenues_scaled_aux);
Tax_Multiplier.Y_Corp = Tax_Multiplier.Y_Corp(1:Multiplier_Horizon);
Cumulative_Tax_Multiplier.Y_Corp = Cumulative_Tax_Multiplier.Y_Corp(1:Multiplier_Horizon);

% Corporate Investment
Tax_Multiplier.I_Corp = ( Reform_level.I_Corp - Reform_level.I_Corp(1) ) ./ Revenues_scaled_aux;
Cumulative_Tax_Multiplier.I_Corp = cumsum( ( Reform_level.I_Corp - Reform_level.I_Corp(1) ) ) ./ cumsum(Revenues_scaled_aux);
Tax_Multiplier.I_Corp = Tax_Multiplier.I_Corp(1:Multiplier_Horizon);
Cumulative_Tax_Multiplier.I_Corp = Cumulative_Tax_Multiplier.I_Corp(1:Multiplier_Horizon);

% Corporate Payouts
Tax_Multiplier.D_Corp = ( Reform_level.D_Corp - Reform_level.D_Corp(1) ) ./ Revenues_scaled_aux;
Cumulative_Tax_Multiplier.D_Corp = cumsum( ( Reform_level.D_Corp - Reform_level.D_Corp(1) ) ) ./ cumsum(Revenues_scaled_aux);
Tax_Multiplier.D_Corp = Tax_Multiplier.D_Corp(1:Multiplier_Horizon);
Cumulative_Tax_Multiplier.D_Corp = Cumulative_Tax_Multiplier.D_Corp(1:Multiplier_Horizon);


% Real GDP
Tax_Multiplier.Y_Aggregate_Real = ( Reform_level.Y_Aggregate_Real - Reform_level.Y_Aggregate_Real(1) ) ./ Revenues_scaled_aux;
Cumulative_Tax_Multiplier.Y_Aggregate_Real = cumsum( ( Reform_level.Y_Aggregate_Real - Reform_level.Y_Aggregate_Real(1) ) ) ./ cumsum(Revenues_scaled_aux);
Tax_Multiplier.Y_Aggregate_Real = Tax_Multiplier.Y_Aggregate_Real(1:Multiplier_Horizon);
Cumulative_Tax_Multiplier.Y_Aggregate_Real = Cumulative_Tax_Multiplier.Y_Aggregate_Real(1:Multiplier_Horizon);


% Real Investment
Tax_Multiplier.I_Aggregate_Real = ( Reform_level.I_Aggregate_Real - Reform_level.I_Aggregate_Real(1) ) ./ Revenues_scaled_aux;
Cumulative_Tax_Multiplier.I_Aggregate_Real = cumsum( ( Reform_level.I_Aggregate_Real - Reform_level.I_Aggregate_Real(1) ) ) ./ cumsum(Revenues_scaled_aux);
Tax_Multiplier.I_Aggregate_Real = Tax_Multiplier.I_Aggregate_Real(1:Multiplier_Horizon);
Cumulative_Tax_Multiplier.I_Aggregate_Real = Cumulative_Tax_Multiplier.I_Aggregate_Real(1:Multiplier_Horizon);


end