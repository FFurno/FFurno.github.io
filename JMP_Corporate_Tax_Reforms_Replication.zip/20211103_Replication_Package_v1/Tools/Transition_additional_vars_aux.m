function [IRF_level, IRF] = Transition_additional_vars_aux(IRF_level, IRF)

IRF_level.Y_Aggregate_Real = IRF_level.Y_Corp + IRF_level.p(1) * IRF_level.Y_PT;
IRF_level.C_Aggregate_Real = IRF_level.C_Corp + IRF_level.p(1) * IRF_level.C_PT;
IRF_level.I_Aggregate_Real = IRF_level.I_Corp + IRF_level.p(1) * IRF_level.I_PT;

IRF.Y_Aggregate_Real = 100 * (IRF_level.Y_Aggregate_Real ./ IRF_level.Y_Aggregate_Real(1) - 1);
IRF.C_Aggregate_Real = 100 * (IRF_level.C_Aggregate_Real ./ IRF_level.C_Aggregate_Real(1) - 1);
IRF.I_Aggregate_Real = 100 * (IRF_level.I_Aggregate_Real ./ IRF_level.I_Aggregate_Real(1) - 1);

IRF.Y_Cshare = IRF_level.Y_Corp ./ IRF_level.Y_Aggregate_Real;
IRF.I_Cshare = IRF_level.I_Corp ./ IRF_level.I_Aggregate_Real;



end
