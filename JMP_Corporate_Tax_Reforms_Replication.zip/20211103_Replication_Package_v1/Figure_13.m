%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 13
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;

%%%%%%%%%%%%%%%%%%%%%%%
% Model Parameters 
alpha = 0.35;
delta = 0.10;
rho = 0.06;
implied_beta = 1 / 1 - rho;
alpha_ratio = alpha / (1 - alpha);
theta = 0; 



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Distortion Index for Output
% Tax Rate = 1 --> Distortion is +Infinity
% Full Expensing --> Distortion is Zero

% Tax Rates and Tax Depreciation Rates
tau_range = (0 : 0.05 : 0.7)';
lambda_tilde_range = (0.60 : 0.05 : 1)';

distortion_index_lambda = zeros(length(tau_range), length(lambda_tilde_range));



for lambda_index = 1 : length(lambda_tilde_range)
    distortion_index_lambda(:, lambda_index) = 100 *  (1 -  ((1 - tau_range) ./ (1 - lambda_tilde_range(lambda_index) .* tau_range)).^alpha_ratio);
end

% Flipping Upside-Down for Axes Labels
distortion_index_lambda = flipud(distortion_index_lambda);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TO EXTRACT CUSTOM COLORMAP =  Heatmaps with Distortion Index
figure('Name', 'Distortion Index for Output - HeatMap');
hh = heatmap(lambda_tilde_range, flipud(tau_range), distortion_index_lambda);
CUSTOM_COLORMAP = hh.Colormap;
grid off
title('Distortion Index for Output')
xlabel('PDV of Depreciation Schedule (\lambda^{\pi})')
ylabel('Corporate Tax Rate (\tau^{\pi})');
close

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Format: PDV, Tax Rate
Coordinates_1961 = [0.65, 0.52];
Coordinates_1980 = [0.80, 0.46];
Coordinates_2002 = [0.915, 0.35];
Coordinates_2017 = [0.94, 0.35];
Coordinates_2021 = [0.98, 0.21];

Distortion_1961 = round(100 *  (1 -  ((1 - Coordinates_1961(2)) ./ (1 - Coordinates_1961(1) .* Coordinates_1961(2))).^alpha_ratio), 2);
Distortion_1980 = round(100 *  (1 -  ((1 - Coordinates_1980(2)) ./ (1 - Coordinates_1980(1) .* Coordinates_1980(2))).^alpha_ratio), 2);
Distortion_2002 = round(100 *  (1 -  ((1 - Coordinates_2002(2)) ./ (1 - Coordinates_2002(1) .* Coordinates_2002(2))).^alpha_ratio), 2);
Distortion_2017 = round(100 *  (1 -  ((1 - Coordinates_2017(2)) ./ (1 - Coordinates_2017(1) .* Coordinates_2017(2))).^alpha_ratio), 2);
Distortion_2021 = round(100 *  (1 -  ((1 - Coordinates_2021(2)) ./ (1 - Coordinates_2021(1) .* Coordinates_2021(2))).^alpha_ratio), 2);




%%%%%%%%%%%%
figure('Name', 'Figure 13');
set(gcf, 'Position',  [570.6000 517 584.8000 468.8000],  'Color', 'w');
contourf(lambda_tilde_range, flipud(tau_range), distortion_index_lambda);
colormap(CUSTOM_COLORMAP);
c = colorbar;
hold on
plot(Coordinates_1961(1), Coordinates_1961(2), '.r', 'MarkerSize', 20);
text(Coordinates_1961(1) + 0.01, Coordinates_1961(2) + 0.01, strcat(string(Distortion_1961), '% (1961)'));

plot(Coordinates_1980(1), Coordinates_1980(2), '.r', 'MarkerSize', 20);
text(Coordinates_1980(1) + 0.005, Coordinates_1980(2) + 0.01, strcat(string(Distortion_1980), '% (1980)'));

plot(Coordinates_2002(1), Coordinates_2002(2), '.r', 'MarkerSize', 20);
text(Coordinates_2002(1) - 0.09, Coordinates_2002(2) + 0.01, strcat(string(Distortion_2002), '% (2002)'));

plot(Coordinates_2017(1), Coordinates_2017(2), '.r', 'MarkerSize', 20);
text(Coordinates_2017(1) - 0.0125, Coordinates_2017(2) - 0.025, strcat(string(Distortion_2017), '% (2017)'));

plot(Coordinates_2021(1), Coordinates_2021(2), '.r', 'MarkerSize', 20);
text(Coordinates_2021(1) - 0.09, Coordinates_2021(2) + 0.01, strcat(string(Distortion_2021), '% (2021)'));
hold off
grid off
title('Long-Run Output Distortion')
xlabel('PDV of Depreciation Schedule (\lambda^{\pi})')
ylabel('Corporate Tax Rate (\tau^{\pi})');







