%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 9
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Preliminary Operations
clear, clc; 
addpath(genpath('./Tools/'));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model - TCJA-17 Simulation


%%%%%%%%%%%%%
% 1) Both Tax Rate Cut and Bonus Depreciation
dynare Dynare_Model_Extended
steady;
[Trump_level_extended, Trump_extended] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_extended, Trump_extended] = Transition_additional_vars_aux(Trump_level_extended, Trump_extended);


% 2) Tax Rate Cut Only
dynare Dynare_Model_Extended
set_param_value('delta_pi_before', 0.4823);
set_param_value('delta_pi_after',  0.4823);
steady;
[Trump_level_extended_rate, Trump_extended_rate] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_extended_rate, Trump_extended_rate] = Transition_additional_vars_aux(Trump_level_extended_rate, Trump_extended_rate);


% 3) Bonus Depreciation Only
dynare Dynare_Model_Extended
steady;
[Trump_level_extended_depreciation, Trump_extended_depreciation] = Transition_extractor([0.35, 0], [0.35, 1], 10000);
[Trump_level_extended_depreciation, Trump_extended_depreciation] = Transition_additional_vars_aux(Trump_level_extended_depreciation, Trump_extended_depreciation);


% Cleaning
clean_dynare_output('Dynare_Model_Extended');



%%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing TCJA-17 Empirical Evidence
load('./Inputs/Empirics_Response.mat');

% Using Corporate Tax Revenues Adjusted for Repatriated Profit
TCJA_17_MACRO.T_pi.Actual = TCJA_17_MACRO.T_pi.Actual_Adjusted;
 
IRF_MACRO = IRF_rescaling_aux(TCJA_17_MACRO, 2017);
IRF_IBES  = IRF_rescaling_aux(TCJA_17_IBES, 2017);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualizing
Color1 = [0, 0.4470, 0.7410];
Color2 = [0.8500, 0.3250, 0.0980];
Color3 = [0.4940 0.1840 0.5560];
Color4 = [0.6350 0.0780 0.1840];
x_axis = [2017:2017+length(Trump_extended.C_Aggregate)-1];
periods_plot = 5;
Bands_alpha = 0.3;


%%%%%%%%%%%%%%%%%%%%%
% Figure 9
figure('Name', 'Figure 9');
set(gcf, 'Color', 'w', 'Position',  [282.6000 588.2000 1.1976e+03 384]);
subplot(1, 2, 1)
hold on
plot(x_axis, Trump_extended.I_Corp, '-o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended_rate.I_Corp, '--o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended_depreciation.I_Corp, ':o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended.I_Corp - (Trump_extended_rate.I_Corp + Trump_extended_depreciation.I_Corp), '-o', 'Color', Color3, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
xticks(2017:2017+periods_plot-1);
ax_aux = get(gca); line(ax_aux.XLim, [0, 0], 'Color', 'k', 'LineStyle', '-');

ylim([-10, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporations Investment');
legend('Both Provisions', 'Tax Rate Cut', 'Bonus Depreciation', 'Interaction', 'Location', 'northwest', 'FontSize', 9);


subplot(1, 2, 2)
hold on
plot(x_axis, Trump_extended.T_Corp, '-o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended_rate.T_Corp, '--o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended_depreciation.T_Corp, ':o', 'Color', Color1, 'LineWidth', 1.5);
plot(x_axis, Trump_extended.T_Corp - (Trump_extended_rate.T_Corp + Trump_extended_depreciation.T_Corp), '-o', 'Color', Color3, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
xticks(2017:2017+periods_plot-1);
ax_aux = get(gca); line(ax_aux.XLim, [0, 0], 'Color', 'k', 'LineStyle', '-');
box on, grid;
ylim([-85, 50]);
ytickformat('percentage');
title('Corporate Tax Revenues');










