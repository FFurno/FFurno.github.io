%% The Macroeconomic Effects of Corporate Tax Reforms
% Table 3
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;
addpath(genpath('./Tools/'));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Steady-State in the Model
dynare Dynare_Model_Baseline
steady;
[SS, SS_exo] = SS_extractor(oo_, M_);
GDP_Shares = SS_GDP_Shares(SS, SS.Y_Aggregate);
clean_dynare_output('Dynare_Model_Baseline');


% Displaying Relevant Ones
Model_Shares.I_Aggregate = GDP_Shares.I_Aggregate;
Model_Shares.pi_Corp = GDP_Shares.pi_Corp;
Model_Shares.D_Corp = GDP_Shares.D_Corp;
Model_Shares.T_Corp = GDP_Shares.T_Corp;
Model_Shares.T_II = GDP_Shares.T_II;

%%%%%%%%%%%%%%%%%%%%%%%%%%
% SS Moments in the Data

labels = {'GDP', 'Inv', 'pi', 'D', 'T_II', 'T_pi'};
series_id = {'GDPA', 'GPDIA', 'A446RC1A027NBEA', 'A449RC1A027NBEA', ...
            'A074RC1A027NBEA', 'A054RC1A027NBEA'};
request = containers.Map(labels, series_id);
SS_Moments_Data = FRED_Interface(request);


% Subsample 2010-2019
SS_Moments_Data = SS_Moments_Data(timerange("2012-01-01","2018-01-01"), :);
SS_Moments_Data = retime(SS_Moments_Data, 'yearly', 'mean');

% Empirical Shares
Empirical_Shares.I_share = mean(SS_Moments_Data.Inv ./ SS_Moments_Data.GDP);
Empirical_Shares.pi_share = mean(SS_Moments_Data.pi ./ SS_Moments_Data.GDP);
Empirical_Shares.D_share = mean(SS_Moments_Data.D ./ SS_Moments_Data.GDP);
Empirical_Shares.T_pi_share = mean(SS_Moments_Data.T_pi ./ SS_Moments_Data.GDP);
Empirical_Shares.T_II_share = mean(SS_Moments_Data.T_II ./ SS_Moments_Data.GDP);


% Table 3 Content
Model_Shares
Empirical_Shares






