%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 3&4
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: R2020a, R2020b

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Ops
clear, clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Import Data
addpath('./Inputs/');
addpath('./Tools/');
IBES_I = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'CPX');
IBES_Y = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'SAL');
IBES_E = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'EMP');
IBES_NET = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'NET');
IBES_EBT = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'EBT');
IBES_D = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'DIV');
IBES_BB = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'BB');
IBES_PAY = readtable('./Inputs/IBES_Forecasts.xlsx', 'sheet', 'PAY');



% Compustat - Scaling with Base Year = 2017
COMPUSTAT = readtable('./Inputs/Compustat.csv');
COMPUSTAT_scaled = COMPUSTAT;

for index_i = 1 : size(COMPUSTAT, 1)
    for index_j = 2 : length(COMPUSTAT.Properties.VariableNames)
        var_name_aux = COMPUSTAT.Properties.VariableNames{index_j};
        var_aux = COMPUSTAT.(var_name_aux);
        COMPUSTAT_scaled.(var_name_aux)(index_i) = 100 * var_aux(index_i) ./ var_aux(2);
    end  
end

Time = datetime([COMPUSTAT_scaled.Year, ones(size(COMPUSTAT_scaled.Year)), ones(size(COMPUSTAT_scaled.Year))]);
COMPUSTAT_scaled = addvars(COMPUSTAT_scaled, Time, 'Before', 'Year');
COMPUSTAT_scaled = table2timetable(COMPUSTAT_scaled);
clear Time


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Change Time Variable of Each IBES Variable
    
% Output (SAL)
Time = datetime([IBES_Y.YEAR, ones(size(IBES_Y.YEAR)), ones(size(IBES_Y.YEAR))]);
IBES_Y = addvars(IBES_Y, Time, 'Before', 'YEAR');
IBES_Y = table2timetable(IBES_Y);
clear Time


% Investment (CPX)
Time = datetime([IBES_I.YEAR, ones(size(IBES_I.YEAR)), ones(size(IBES_I.YEAR))]);
IBES_I = addvars(IBES_I, Time, 'Before', 'YEAR');
IBES_I = table2timetable(IBES_I);
clear Time


% Employment (EMP)
Time = datetime([IBES_E.YEAR, ones(size(IBES_E.YEAR)), ones(size(IBES_E.YEAR))]);
IBES_E = addvars(IBES_E, Time, 'Before', 'YEAR');
IBES_E = table2timetable(IBES_E);
clear Time


% EBITDA (EBT)
Time = datetime([IBES_EBT.YEAR, ones(size(IBES_EBT.YEAR)), ones(size(IBES_EBT.YEAR))]);
IBES_EBT = addvars(IBES_EBT, Time, 'Before', 'YEAR');
IBES_EBT = table2timetable(IBES_EBT);
clear Time


% Net Income (NET)
Time = datetime([IBES_NET.YEAR, ones(size(IBES_NET.YEAR)), ones(size(IBES_NET.YEAR))]);
IBES_NET = addvars(IBES_NET, Time, 'Before', 'YEAR');
IBES_NET = table2timetable(IBES_NET);
clear Time


% Dividends (DIV)
Time = datetime([IBES_D.YEAR, ones(size(IBES_D.YEAR)), ones(size(IBES_D.YEAR))]);
IBES_D = addvars(IBES_D, Time, 'Before', 'YEAR');
IBES_D = table2timetable(IBES_D);
clear Time


% Buy-Backs (BB)
Time = datetime([IBES_BB.YEAR, ones(size(IBES_BB.YEAR)), ones(size(IBES_BB.YEAR))]);
IBES_BB = addvars(IBES_BB, Time, 'Before', 'YEAR');
IBES_BB = table2timetable(IBES_BB);
clear Time


% Payouts (PAY)
Time = datetime([IBES_PAY.YEAR, ones(size(IBES_PAY.YEAR)), ones(size(IBES_PAY.YEAR))]);
IBES_PAY = addvars(IBES_PAY, Time, 'Before', 'YEAR');
IBES_PAY = table2timetable(IBES_PAY);
clear Time



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Re-formatting Dataset
t_begin = 2011;
Forecast_Year = 2017;

% Computation-Ready Format
FE_Store.Y = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_Y);
FE_Store.I = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_I);
FE_Store.E = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_E);
FE_Store.EBT = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_EBT);
FE_Store.NET = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_NET);
FE_Store.D = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_D);
FE_Store.BB = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_BB);
FE_Store.PAY = FE_Computation_Auxiliary_IBES(t_begin, Forecast_Year, IBES_PAY);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% TCJA-17

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Timing of Forecasts
Year_Span = (Forecast_Year-1 : 1 : Forecast_Year+2)';

% Pre-Allocation TCJA_17 (table with timetables as content)
TCJA_17_IBES.Y = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.E = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.I = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.EBT = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.NET = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.D = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.BB = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));
TCJA_17_IBES.PAY = timetable(datetime(Year_Span, ones(size(Year_Span)), ones(size(Year_Span))));



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 1) Output (Sales) 
Store_aux = FE_Store.Y;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.Y = addvars(TCJA_17_IBES.Y, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux




%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 2) Investment (CPX)

Store_aux = FE_Store.I;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.I = addvars(TCJA_17_IBES.I, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 3) Employment

Store_aux = FE_Store.E;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.E = addvars(TCJA_17_IBES.E, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 4) EBITDA

Store_aux = FE_Store.EBT;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.EBT = addvars(TCJA_17_IBES.EBT, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 5) NET INCOME

Store_aux = FE_Store.NET;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.NET = addvars(TCJA_17_IBES.NET, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 6) DIVIDENDS

Store_aux = FE_Store.D;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.D = addvars(TCJA_17_IBES.D, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux




%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 7) BUYBACKS

Store_aux = FE_Store.BB;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.BB = addvars(TCJA_17_IBES.BB, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux




%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 8) Payouts to Shareholders (PAY)

Store_aux = FE_Store.PAY;

Actual = [ Store_aux(datetime(Forecast_Year, 1, 1), :).Actualb1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual0; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Actual1; Store_aux(datetime(Forecast_Year, 1, 1), :).Actual2];  

Forecast = [nan; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast0; Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast1; ...
            Store_aux(datetime(Forecast_Year, 1, 1), :).Forecast2];

TCJA_17_IBES.PAY = addvars(TCJA_17_IBES.PAY, Actual, Forecast, 'NewVariableNames', {'Actual','Forecast'});

clear Actual Forecast Store_aux





%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Fitting Forecast Errors Distribution

% Kernel Distribution Params
Kernel_Bandwith = 1;
Mass_Center = 0.68;



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Adding Upper and Lower Bounds

% Output
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.Y.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.Y.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.Y.Forecast_lb = [nan, 100, TCJA_17_IBES.Y.Forecast(3) + lb_1_aux, TCJA_17_IBES.Y.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.Y.Forecast_ub = [nan, 100, TCJA_17_IBES.Y.Forecast(3) + ub_1_aux, TCJA_17_IBES.Y.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% Employment
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.E.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.E.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.E.Forecast_lb = [nan, 100, TCJA_17_IBES.E.Forecast(3) + lb_1_aux, TCJA_17_IBES.E.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.E.Forecast_ub = [nan, 100, TCJA_17_IBES.E.Forecast(3) + ub_1_aux, TCJA_17_IBES.E.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% Investment
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.I.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.I.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.I.Forecast_lb = [nan, 100, TCJA_17_IBES.I.Forecast(3) + lb_1_aux, TCJA_17_IBES.I.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.I.Forecast_ub = [nan, 100, TCJA_17_IBES.I.Forecast(3) + ub_1_aux, TCJA_17_IBES.I.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% EBITDA
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.EBT.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.EBT.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.EBT.Forecast_lb = [nan, 100, TCJA_17_IBES.EBT.Forecast(3) + lb_1_aux, TCJA_17_IBES.EBT.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.EBT.Forecast_ub = [nan, 100, TCJA_17_IBES.EBT.Forecast(3) + ub_1_aux, TCJA_17_IBES.EBT.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% NET INCOME 
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.NET.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.NET.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.NET.Forecast_lb = [nan, 100, TCJA_17_IBES.NET.Forecast(3) + lb_1_aux, TCJA_17_IBES.NET.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.NET.Forecast_ub = [nan, 100, TCJA_17_IBES.NET.Forecast(3) + ub_1_aux, TCJA_17_IBES.NET.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% DIV
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.D.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.D.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.D.Forecast_lb = [nan, 100, TCJA_17_IBES.D.Forecast(3) + lb_1_aux, TCJA_17_IBES.D.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.D.Forecast_ub = [nan, 100, TCJA_17_IBES.D.Forecast(3) + ub_1_aux, TCJA_17_IBES.D.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% BB
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.BB.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.BB.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.BB.Forecast_lb = [nan, 100, TCJA_17_IBES.BB.Forecast(3) + lb_1_aux, TCJA_17_IBES.BB.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.BB.Forecast_ub = [nan, 100, TCJA_17_IBES.BB.Forecast(3) + ub_1_aux, TCJA_17_IBES.BB.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux


% PAYOUTS 
[lb_1_aux, ub_1_aux] = FE_Kernel_Percentiles_Aux(FE_Store.PAY.FE1, Kernel_Bandwith, Mass_Center);
[lb_2_aux, ub_2_aux] = FE_Kernel_Percentiles_Aux(FE_Store.PAY.FE2, Kernel_Bandwith, Mass_Center);
TCJA_17_IBES.PAY.Forecast_lb = [nan, 100, TCJA_17_IBES.PAY.Forecast(3) + lb_1_aux, TCJA_17_IBES.PAY.Forecast(4) + lb_2_aux]';
TCJA_17_IBES.PAY.Forecast_ub = [nan, 100, TCJA_17_IBES.PAY.Forecast(3) + ub_1_aux, TCJA_17_IBES.PAY.Forecast(4) + ub_2_aux]';
clear lb_aux ub_aux






%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot Settings
Color_actuals = [0, 0.4470, 0.7410];
Color_forecasts = [0.8500, 0.3250, 0.0980];
Bands_alpha = 0.25;
x_axis = 2016:2019;



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 3
figure('Name', 'Figure 3');
set(gcf, 'Color', 'w', 'Position', [89.8000 405 1.4112e+03 596.8000]);
subplot(2, 3, 1)
hold on
plot_actual = plot(x_axis, TCJA_17_IBES.Y.Actual, '-o', 'LineWidth', 1.5);
plot_forecast = plot(x_axis, TCJA_17_IBES.Y.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot_bands = confidence_bands(x_axis, TCJA_17_IBES.Y.Forecast_lb, TCJA_17_IBES.Y.Forecast_ub, Color_forecasts, Bands_alpha);  
hold off
ylim([90, 115]);
box on, grid;
title('Output');
xticks(x_axis);
legend([plot_actual, plot_forecast, plot_bands(2)], 'Actual', 'Forecast', 'FE Distribution', 'Location', 'northwest', ...
    'FontSize', 8);


subplot(2, 3, 2)
hold on
plot(x_axis, TCJA_17_IBES.I.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.I.Forecast_lb, TCJA_17_IBES.I.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.I.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([90, 125]);
box on, grid;
title('Investment');
xticks(x_axis);


subplot(2, 3, 3)
hold on
plot(x_axis, TCJA_17_IBES.E.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.E.Forecast_lb, TCJA_17_IBES.E.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.E.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([95, 115]);
box on, grid;
title('Employment');
xticks(x_axis);


subplot(2, 3, 4)
hold on
plot(x_axis, TCJA_17_IBES.EBT.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.EBT.Forecast_lb, TCJA_17_IBES.EBT.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.EBT.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([90, 120]);
box on, grid;
title('Pre-Tax Income');
xticks(x_axis);


subplot(2, 3, 5)
hold on
plot(x_axis, TCJA_17_IBES.NET.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.NET.Forecast_lb, TCJA_17_IBES.NET.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.NET.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([85, 125]);
box on, grid;
title('After-Tax Income');
xticks(x_axis);


subplot(2, 3, 6)
hold on
plot(x_axis, TCJA_17_IBES.PAY.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.PAY.Forecast_lb, TCJA_17_IBES.PAY.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.PAY.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
ylim([80, 140]);
box on, grid;
title('Payouts to Shareholders');
xticks(x_axis);



%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 4
figure('Name', 'Figure 4');
set(gcf, 'Color', 'w', 'Position', [89.8000 405 1.4112e+03 596.8000]);
subplot(2, 3, 1)
hold on
plot_actual = plot(x_axis, TCJA_17_IBES.Y.Actual, '-o', 'LineWidth', 1.5);
plot_forecast = plot(x_axis, TCJA_17_IBES.Y.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot_bands = confidence_bands(x_axis, TCJA_17_IBES.Y.Forecast_lb, TCJA_17_IBES.Y.Forecast_ub, Color_forecasts, Bands_alpha);  
plot_compustat = plot(x_axis, COMPUSTAT_scaled.SALE, '-o', 'LineWidth', 1.5);
hold off
ylim([90, 115]);
box on, grid;
title('Output');
xticks(x_axis);
legend([plot_actual, plot_forecast, plot_bands(2), plot_compustat], 'Actual', 'Forecast', 'FE Distribution', 'Compustat Universe', ...
            'Location', 'northwest', 'FontSize', 8);


subplot(2, 3, 2)
hold on
plot(x_axis, TCJA_17_IBES.I.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.I.Forecast_lb, TCJA_17_IBES.I.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.I.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot(x_axis, COMPUSTAT_scaled.CPX, '-o', 'LineWidth', 1.5);
hold off
ylim([90, 125]);
box on, grid;
title('Investment');
xticks(x_axis);




subplot(2, 3, 3)
hold on
plot(x_axis, TCJA_17_IBES.E.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.E.Forecast_lb, TCJA_17_IBES.E.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.E.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot(x_axis, COMPUSTAT_scaled.EMP, '-o', 'LineWidth', 1.5);
hold off
ylim([95, 115]);
box on, grid;
title('Employment');
xticks(x_axis);


subplot(2, 3, 4)
hold on
plot(x_axis, TCJA_17_IBES.EBT.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.EBT.Forecast_lb, TCJA_17_IBES.EBT.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.EBT.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot(x_axis, COMPUSTAT_scaled.EBITDA, '-o', 'LineWidth', 1.5);
hold off
ylim([90, 120]);
box on, grid;
title('Pre-Tax Income');
xticks(x_axis);


subplot(2, 3, 5)
hold on
plot(x_axis, TCJA_17_IBES.NET.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.NET.Forecast_lb, TCJA_17_IBES.NET.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.NET.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot(x_axis, COMPUSTAT_scaled.NET, '-o', 'LineWidth', 1.5);
hold off
ylim([85, 125]);
box on, grid;
title('After-Tax Income');
xticks(x_axis);



subplot(2, 3, 6)
hold on
plot(x_axis, TCJA_17_IBES.PAY.Actual, '-o', 'LineWidth', 1.5);
confidence_bands(x_axis, TCJA_17_IBES.PAY.Forecast_lb, TCJA_17_IBES.PAY.Forecast_ub, Color_forecasts, Bands_alpha);  
plot(x_axis, TCJA_17_IBES.PAY.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
plot(x_axis, COMPUSTAT_scaled.PAYOUT, '-o', 'LineWidth', 1.5);
hold off
ylim([80, 140]);
box on, grid;
title('Payouts to Shareholders');
xticks(x_axis);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bonus Figure -  Robustness: Valued Added and Alternative Measure of Payouts
figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [227.4000 477.8000 1.3424e+03 423.2000]);
subplot(1, 2, 1)
hold on
plot(COMPUSTAT_scaled.Time, COMPUSTAT_scaled.SALE, '-o', 'LineWidth', 1.5);
plot(COMPUSTAT_scaled.Time, COMPUSTAT_scaled.VA, '-o', 'LineWidth', 1.5);
hold off
box on, grid;
title('Output');
legend('Sales', 'Value Added', 'Location', 'northwest');


subplot(1, 2, 2)
hold on
plot(COMPUSTAT_scaled.Time, COMPUSTAT_scaled.BB, '-o', 'LineWidth', 1.5);
plot(COMPUSTAT_scaled.Time, COMPUSTAT_scaled.BB_adj, '-o', 'LineWidth', 1.5);
hold off
box on, grid;
title('Buy-Backs: Two Measures');
legend('Purchase of Common and Preferred Stock', 'x - Preferred Stock Redemption Value','Location', 'northwest', 'FontSize', 8);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Bonus Figure - Payouts Decomposition: Dividends vs Buybacks

figure('Name', 'Bonus Figure');
set(gcf, 'Color', 'w', 'Position', [202.6000 533 1.1624e+03 352.8]);
subplot(1, 2, 1)
hold on
plot_actual = plot(x_axis, TCJA_17_IBES.D.Actual, '-o', 'LineWidth', 1.5);
plot_bands = confidence_bands(x_axis, TCJA_17_IBES.D.Forecast_lb, TCJA_17_IBES.D.Forecast_ub, Color_forecasts, Bands_alpha);  
plot_forecast = plot(x_axis, TCJA_17_IBES.D.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
box on, grid;
ylim([90, 120]);
title('Dividends');
xticks(x_axis);
legend([plot_actual, plot_forecast, plot_bands(2)], 'Actual', 'Forecast', 'FE Distribution', 'Location', 'northwest', ...
    'FontSize', 8);


subplot(1, 2, 2)
hold on
plot_actual = plot(x_axis, TCJA_17_IBES.BB.Actual, '-o', 'LineWidth', 1.5);
plot_bands = confidence_bands(x_axis, TCJA_17_IBES.BB.Forecast_lb, TCJA_17_IBES.BB.Forecast_ub, Color_forecasts, Bands_alpha);  
plot_forecast = plot(x_axis, TCJA_17_IBES.BB.Forecast, '-o', 'Color', Color_forecasts, 'LineWidth', 1.5);
hold off
box on, grid;
title('Stock Buybacks');
xticks(x_axis);







