%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 1
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Ops
clear, clc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loading Data
Predictit = readtable('./Inputs/PredictIt.xlsx');
IBES_Forecasts = readtable('./Inputs/IBES_Forecast_Rolling.xlsx');
IBES_Forecasts.Forecasting_Date =  datetime(IBES_Forecasts.Forecasting_Date, 'InputFormat','yyyy-MM-dd');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% PredictIt -  Smoothing
moving_mean_size = 15;
corporate_smooth = movmean(Predictit.CORP_TAXCUT_2017, [moving_mean_size, moving_mean_size]);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
t0 = datetime([2016, 11, 09]);
t1 = datetime([2017, 12, 31]);
t_introduction = datetime([2017, 11, 2]);
t_senate = datetime([2017, 12, 2]);
t_signed = datetime([2017, 12, 22]);

xticks_aux = [t0, datetime(2017, 3, 1), datetime(2017, 5, 1),  datetime(2017, 7, 1), datetime(2017, 9, 1), t_introduction, t_senate, t_signed];
xticks_labels_aux = {'Trump Elected'; 'March 2017'; 'May 2017'; 'July 2017'; 'Sept 2017'; 'Bill Introduction'; 'Senate Pass'; 'Law Signed'};
xtick_angle_aux = 40;


figure('Name', 'Figure 1');
set(gcf, 'Color', 'w', 'Position', [362.6000 508.2000 926.4000 379.2000]);
subplot(1, 2, 1)
hold on
plot(Predictit.Date, corporate_smooth, 'LineWidth', 1.5);
plot(Predictit.Date, Predictit.CORP_TAXCUT_2017, '-', 'Color', [0, 0.4470, 0.7410 0.2], 'LineWidth', 1);
line([t_introduction, t_introduction], [0, 100], 'Color', 'black','LineStyle', '--');
line([t_senate, t_senate], [0, 100], 'Color', 'black','LineStyle', '--');
line([t_signed, t_signed], [0, 100], 'Color', 'black','LineStyle', '--');
hold off
ylabel('Market Probability','fontweight','bold'); 
title('(a) Betting Markets');
grid; box on;
ylim([0, 100]);
xlim([t0, t1]);
xticks(xticks_aux);
xticklabels(xticks_labels_aux);
legend('"Corporate Tax Cut by 2017"', 'Location', 'southwest');
xtickangle(xtick_angle_aux)
ytickformat('percentage');

subplot(1, 2, 2)
hold on
plot(IBES_Forecasts.Forecasting_Date(1:end-2), IBES_Forecasts.CAPEX_g(1:end-2), '-o', 'LineWidth', 1.5);
line([t_introduction, t_introduction], [0, 6], 'Color', 'black','LineStyle', '--');
line([t_senate, t_senate], [0, 6], 'Color', 'black','LineStyle', '--');
line([t_signed, t_signed], [0, 6], 'Color', 'black','LineStyle', '--');
hold off
grid; box on;
title('(b) IBES Forecasts of CAPEX Growth');
ylabel('Growth Rate','fontweight','bold'); 
xlim([t0, t1]);
ylim([0, 6]);
xticks(xticks_aux);
xticklabels(xticks_labels_aux);
xtickangle(xtick_angle_aux)
ytickformat('percentage');
