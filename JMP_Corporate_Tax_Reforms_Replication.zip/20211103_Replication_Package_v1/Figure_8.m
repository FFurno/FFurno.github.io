%% The Macroeconomic Effects of Corporate Tax Reforms
% Figure 8
% Author: Francesco Furno
% Last Revision: 7 November 2021
% Guaranteed Compatibility: MATLAB R2020a, Dynare 4.5.7

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Preliminary Operations
clear, clc;
addpath(genpath('./Tools/'));


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Model - TCJA-17 Simulation

%%%%%%%%%%%%%
% Baseline
dynare Dynare_Model_Baseline
steady;
[Trump_level, Trump] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level, Trump] = Transition_additional_vars_aux(Trump_level, Trump);



%%%%%%%%%%%%%
% Endogenous Labor + CES + Variable Capital Utilization
dynare Dynare_Model_Extended
steady;
[Trump_level_extended, Trump_extended] = Transition_extractor([0.35, 0], [0.21, 1], 10000);
[Trump_level_extended, Trump_extended] = Transition_additional_vars_aux(Trump_level_extended, Trump_extended);


% Checking Value of Depreciation Elasticity (King&Rebelo = 0.10; Basu&Kimball = 1.0);
Depreciation_elasticity = delta_2 ./ (delta_1 + delta_2 .* (Trump_level_extended.u - 1) ) .* Trump_level_extended.u;


%%%%%%%%%%%%
% Cleaning
clean_dynare_output('Dynare_Model_Baseline');
clean_dynare_output('Dynare_Model_Extended');



%%%%%%%%%%%%%%%%%%%%%%%%%%
% Importing TCJA-17 Empirical Evidence
load('./Inputs/Empirics_Response.mat');

% Using Corporate Tax Revenues Adjusted for Repatriated Profit
TCJA_17_MACRO.T_pi.Actual = TCJA_17_MACRO.T_pi.Actual_Adjusted;
 

IRF_MACRO = IRF_rescaling_aux(TCJA_17_MACRO, 2017);
IRF_IBES  = IRF_rescaling_aux(TCJA_17_IBES, 2017);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualizing
Color1 = [0, 0.4470, 0.7410];
Color2 = [0.8500, 0.3250, 0.0980];
Color3 = [0.4660, 0.6740, 0.1880];
x_axis = [2017:2017+length(Trump.C_Aggregate)-1];
periods_plot = 5;
Bands_alpha = 0.3;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Figure 8
figure('Name', 'Figure 8');
set(gcf, 'Color', 'w', 'Position', [34.6000 442.6000 1.3944e+03 508.8000]);

subplot(2, 4, 1)
hold on
plot_model = plot(x_axis, Trump.Y_Aggregate_Real, '-o', 'LineWidth', 1.5);
plot_model_extended = plot(x_axis, Trump_extended.Y_Aggregate_Real, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.Y.lb, IRF_MACRO.Y.ub, Color2, Bands_alpha);  
plot_data = plot(IRF_MACRO.Year, [IRF_MACRO.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);

hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 4]);
box on, grid;
ytickformat('percentage');
title('Aggregate Output');
legend([plot_data, plot_model, plot_model_extended], 'Data', 'Baseline Model', 'Extended Model', 'Location', 'northeast', 'FontSize', 8);


subplot(2, 4, 2)
hold on
plot(x_axis, Trump.I_Aggregate_Real, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.I_Aggregate_Real, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.I_NR.lb, IRF_MACRO.I_NR.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.I_NR.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 6]);
box on, grid;
ytickformat('percentage');
title('Aggregate Non-Residential Investment')


subplot(2, 4, 3)
hold on 
plot(x_axis, Trump.L_Aggregate, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.L_Aggregate, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.E.lb, IRF_MACRO.E.ub, Color2, Bands_alpha);  
plot_aggregate = plot(IRF_MACRO.Year, IRF_MACRO.E.point, '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-1, 1]);
title('Aggregate Employment');
box on, grid;
ytickformat('percentage');


subplot(2, 4, 4)
hold on
plot(x_axis, Trump.T_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.T_Corp, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_MACRO.Year, IRF_MACRO.T_pi.lb, IRF_MACRO.T_pi.ub, Color2, Bands_alpha);  
plot(IRF_MACRO.Year, [IRF_MACRO.T_pi.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('Corporate Tax Revenues')


subplot(2, 4, 5)
hold on
plot(x_axis, Trump.Y_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.Y_Corp, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.Y.lb, IRF_IBES.Y.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.Y.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 20]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Output')


subplot(2, 4, 6)
hold on
plot(x_axis, Trump.I_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.I_Corp, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.I.lb, IRF_IBES.I.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.I.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 25]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Investment')


subplot(2, 4, 7)
hold on
plot(x_axis, Trump.L_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.L_Corp, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.E.lb, IRF_IBES.E.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.E.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
ylim([-5, 10]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Employment')


subplot(2, 4, 8)
hold on
plot(x_axis, Trump.D_Corp, '-o', 'LineWidth', 1.5);
plot(x_axis, Trump_extended.D_Corp, '-o', 'Color', Color3, 'LineWidth', 1.5);
confidence_bands(IRF_IBES.Year, IRF_IBES.PAY.lb, IRF_IBES.PAY.ub, Color2, Bands_alpha);  
plot(IRF_IBES.Year, [IRF_IBES.PAY.point], '-o', 'Color', Color2, 'LineWidth', 1.5);
hold off
xlim([2017, 2017+periods_plot-1]);
box on, grid;
ytickformat('percentage');
title('C-Corporate Payouts')





