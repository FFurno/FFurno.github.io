function [varlist, varlist_exo] = var_list_extractor(M_)

varlist = M_.endo_names;
varlist_exo = M_.exo_names;

end